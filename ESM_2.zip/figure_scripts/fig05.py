"""Fig. 5 Measured vs LOSO-predicted (SVR). Plot interior is the original raster, recoloured pixel-exactly;
axes, ticks, labels and annotations rebuilt. R² values from Table 5."""
import numpy as np, matplotlib.pyplot as plt
import jstyle as J, rasterkit as rk, rpanel as R
J.use()
a = rk.load("../raw/image5.png")
PLUM, LBLUE = "#8E5F86", "#8FA9D2"
mp = {rk.OLD["blue"]: J.TEAL, rk.OLD["verm"]: J.TERRA, rk.OLD["green"]: J.BLUE, rk.OLD["yellow"]: J.SAGE,
      rk.OLD["pink"]: PLUM, rk.OLD["sky"]: LBLUE}
fig, axs = plt.subplots(1, 2, figsize=(J.W2, 3.45), gridspec_kw=dict(wspace=0.30))
fig.subplots_adjust(left=0.085, right=0.985, top=0.93, bottom=0.13)
spec = [dict(box=(159, 77, 847, 765), xc=([233, 503, 773], [2, 3, 4]), yc=([151, 421, 691], [4, 3, 2]), lab="UCS (kPa)", r2="0.15", n="397 records, 19 held-out studies"),
        dict(box=(1065, 77, 1753, 765), xc=([1110, 1397, 1685], [0, 1, 2]), yc=([145, 433, 720], [2, 1, 0]), lab="CBR (%)", r2="−0.05", n="159 records, 10 held-out studies")]
for ax, s, p in zip(axs, spec, "ab"):
    R.raster_axes(ax, a, s["box"], s["xc"], s["yc"], mapping=mp, neutral=rk.ink_neutral())
    R.log_ticks(ax.xaxis, *ax.get_xlim()); R.log_ticks(ax.yaxis, *ax.get_ylim())
    ax.set_xlabel(f"Measured {s['lab']}"); ax.set_ylabel(f"LOSO-predicted {s['lab']}")
    ax.text(0.97, 0.04, f"SVR, LOSO\n$R^2$ (log) = {s['r2']}\n{s['n']}", transform=ax.transAxes, ha="right", va="bottom", fontsize=8, color=J.INK, linespacing=1.3)
    ax.text(0.04, 0.96, "1:1 (solid)\n×2 and ÷2 (dashed)", transform=ax.transAxes, ha="left", va="top", fontsize=8, color=J.MUTED, linespacing=1.3)
    J.panel(ax, p, x=-0.02, ha="right", y=1.0)
J.save(fig, "Fig05")
