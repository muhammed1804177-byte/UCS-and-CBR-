"""Fig. 3 Random split vs LOSO, exact values from Table 5 (mean ± SD)."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, matplotlib.ticker as mt
import jstyle as J
J.use()
d = pd.read_csv("../data/table5_r2.csv")
n = len(d); y = np.arange(n)[::-1]
fig, axs = plt.subplots(1, 2, figsize=(J.W2, 4.1), sharey=True, gridspec_kw=dict(wspace=0.08))
fig.subplots_adjust(left=0.165, right=0.985, top=0.885, bottom=0.115)
groups = d.group.values
for ax, t, lab in zip(axs, ["ucs", "cbr"], ["UCS", "CBR"]):
    # group bands
    for gname in pd.unique(groups):
        idx = np.where(groups == gname)[0]
        if list(pd.unique(groups)).index(gname) % 2 == 0:
            ax.axhspan(y[idx].min()-0.5, y[idx].max()+0.5, color=J.GREY_XL, alpha=0.55, lw=0, zorder=0)
    ax.axvline(0, color=J.INK2, lw=0.6, zorder=1)
    r, rs, l, ls = d[f"{t}_rand"], d[f"{t}_rand_sd"].fillna(0), d[f"{t}_loso"], d[f"{t}_loso_sd"].fillna(0)
    ax.hlines(y, l, r, color=J.GREY, lw=1.0, zorder=2)
    ax.errorbar(r, y, xerr=rs, fmt="o", ms=4.6, color=J.TEAL, mec="white", mew=0.5, elinewidth=0.8, capsize=1.6, zorder=4, label="Random 5-fold split (5 split seeds)")
    ax.errorbar(l, y, xerr=ls, fmt="s", ms=4.2, color=J.TERRA, mec="white", mew=0.5, elinewidth=0.8, capsize=1.6, zorder=4, label="Leave-one-study-out (3 seed sets)")
    ax.set_xlim(-0.62, 1.30); ax.spines["bottom"].set_bounds(-0.62, 1.0); ax.xaxis.set_major_locator(mt.FixedLocator(np.arange(-0.5, 1.01, 0.25)))
    ax.xaxis.set_major_formatter(mt.FuncFormatter(lambda v, p: f"{v:.2f}".replace("-", "−")))
    ax.set_xlabel(rf"$R^2$ of log$_{{10}}$ {lab}")
    ax.tick_params(axis="y", length=0)
    J.panel(ax, "a" if t == "ucs" else "b", x=0.0, ha="left", y=1.005)
    ax.text(0.075, 1.005, f"{lab}: {'397 records, 19 studies' if t=='ucs' else '159 records, 10 studies'}", transform=ax.transAxes, fontsize=8, va="bottom")
axs[0].set_yticks(y, d.model); axs[0].set_ylim(-0.6, n-0.4)
# group labels on the right of panel b
for gname in pd.unique(groups):
    idx = np.where(groups == gname)[0]
    axs[1].text(1.0, y[idx].mean(), gname.replace(" ", "\n") if gname in ("Tree ensemble","Single network","Hybrid network") else gname, transform=axs[1].get_yaxis_transform(), ha="right", va="center", fontsize=8, color=J.MUTED, style="italic")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=2, bbox_to_anchor=(0.575, 1.0))
J.save(fig, "Fig03")
