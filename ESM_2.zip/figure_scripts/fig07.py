"""Fig. 7 Simulated local calibration (exact Table 7 values + digitized remainder; data/fig07_data.csv)."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, matplotlib.ticker as mt
import jstyle as J
J.use()
d = pd.read_csv("../data/fig07_data.csv")
sty = {"Mean of k local tests": (J.TERRA, "s", "-", -0.10, 1.5),
       "SVR": (J.TEAL, "o", "--", -0.05, 1.0), "DNN": (J.BLUE, "^", "-.", 0.0, 1.0),
       "XGBoost": (J.SAGE, "v", ":", 0.05, 1.2), "Hybrid B + attention": (J.INK, "D", (0, (5, 1.5, 1, 1.5)), 0.10, 1.0)}
lab = {"Mean of k local tests": "Mean of k local tests (k = 0: training mean)", "SVR": "SVR + offset", "DNN": "DNN + offset",
       "XGBoost": "XGBoost + offset", "Hybrid B + attention": "Hybrid B + attention + offset"}
fig, axs = plt.subplots(1, 2, figsize=(J.W2, 3.15), gridspec_kw=dict(wspace=0.26))
fig.subplots_adjust(left=0.085, right=0.985, top=0.78, bottom=0.14)
for ax, tgt, p in zip(axs, ["UCS", "CBR"], "ab"):
    for s, (col, mk, ls, off, lw) in sty.items():
        q = d[(d.target == tgt) & (d.series == s)].sort_values("k")
        x = q.k + off
        ax.plot(x, q.rmse_final, ls=ls, color=col, lw=lw, zorder=2)
        e = q[q.k > 0]
        ax.errorbar(e.k + off, e.rmse_final, yerr=[e.rmse_final - e.lo, e.hi - e.rmse_final], fmt="none", ecolor=col, elinewidth=0.8, capsize=1.6, zorder=2)
        ax.plot(x, q.rmse_final, mk, color=col, ms=4.4 if mk != "D" else 3.8, mec="white", mew=0.5, zorder=3, label=lab[s])
    ax.set_xticks([0, 1, 2, 3]); ax.set_xlim(-0.3, 3.3)
    ax.set_xlabel("Number of local tests, k"); ax.set_ylabel(f"Per-study RMSE (log$_{{10}}$ {tgt})")
    ax.yaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); ax.set_axisbelow(True)
    J.panel(ax, p, x=-0.17, ha="left", y=1.04); ax.text(-0.04, 1.04, f"{tgt}", transform=ax.transAxes, fontsize=8, va="bottom")
axs[0].set_ylim(0.15, 0.45); axs[1].set_ylim(0.23, 0.56)
axs[0].axvspan(0.5, 3.3, color=J.GREY_XL, alpha=0.0)
from matplotlib.lines import Line2D
h = [Line2D([], [], color=c_, ls=ls_, lw=lw_, marker=mk_, ms=4.4, mec="white", mew=0.5) for s_, (c_, mk_, ls_, off_, lw_) in sty.items()]
l = [lab[s_] for s_ in sty]
fig.legend(h, l, loc="upper center", ncol=3, bbox_to_anchor=(0.53, 1.0), columnspacing=1.0)
J.save(fig, "Fig07")
