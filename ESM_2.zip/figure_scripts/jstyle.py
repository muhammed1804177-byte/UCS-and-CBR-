"""Shared journal style for all manuscript figures (ASCE JGGE).
Palette: muted teal, terracotta, restrained blue, sage; charcoal ink; neutral greys.
Typography: Liberation Sans (Arial-metric), 8 pt labels / 7 pt ticks; 7.0 in double-column width."""
import matplotlib as mpl, matplotlib.pyplot as plt, numpy as np
from matplotlib.colors import LinearSegmentedColormap

TEAL, TERRA, BLUE, SAGE = "#028B7A", "#C4592F", "#3866AD", "#85A55E"
INK, INK2, MUTED = "#2B3035", "#4A5057", "#6E757C"
GREY, GREY_L, GREY_XL = "#9AA1A7", "#C9CED2", "#E6E8EA"
CAT = [TEAL, TERRA, BLUE, SAGE, INK]
MARK = ["o", "s", "^", "D", "v"]
LS = ["-", "--", "-.", ":", (0, (5, 1.5, 1, 1.5))]
W2, W1 = 6.85, 3.31     # Springer large-journal widths: 174 mm / 84 mm

def _oklab_to_rgb(L, a, b):
    l_=L+0.3963377774*a+0.2158037573*b; m_=L-0.1055613458*a-0.0638541728*b; s_=L-0.0894841775*a-1.2914855480*b
    l,m,s=l_**3,m_**3,s_**3
    r=4.0767416621*l-3.3077115913*m+0.2309699292*s; g=-1.2684380046*l+2.6097574011*m-0.3413193965*s; bb=-0.0041960863*l-0.7034186147*m+1.7076147010*s
    f=lambda x: np.where(x<=0.0031308,12.92*x,1.055*np.clip(x,0,None)**(1/2.4)-0.055)
    return np.clip(np.stack([f(r),f(g),f(bb)],-1),0,1)
def _rgb_to_oklab(c):
    c=np.asarray(c,float); lin=np.where(c<=0.04045,c/12.92,((c+0.055)/1.055)**2.4)
    r,g,b=lin[...,0],lin[...,1],lin[...,2]
    l=0.4122214708*r+0.5363325363*g+0.0514459929*b; m=0.2119034982*r+0.6806995451*g+0.1073969566*b; s=0.0883024619*r+0.2817188376*g+0.6299787005*b
    l_,m_,s_=np.cbrt(l),np.cbrt(m),np.cbrt(s)
    return np.stack([0.2104542553*l_+0.7936177850*m_-0.0040720468*s_,1.9779984951*l_-2.4285922050*m_+0.4505937099*s_,0.0259040371*l_+0.7827717662*m_-0.8086757660*s_],-1)

def _ramp(hexes, n=256):
    pts=np.array([_rgb_to_oklab(np.array(mpl.colors.to_rgb(h))) for h in hexes])
    t=np.linspace(0,1,n); seg=np.linspace(0,1,len(hexes))
    lab=np.stack([np.interp(t,seg,pts[:,k]) for k in range(3)],-1)
    return _oklab_to_rgb(lab[:,0],lab[:,1],lab[:,2])
# sequential field map: warm paper -> pale sage -> teal -> deep charcoal-blue (monotone lightness)
SEQ_STOPS = ["#F3EFE3", "#C9D9B9", "#7DB4A0", "#2E8580", "#1E5466", "#1F2A38"]
SEQ = LinearSegmentedColormap.from_list("jgge_seq", _ramp(SEQ_STOPS))

def use():
    mpl.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 8, "axes.labelsize": 8.5,
        "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8,
        "axes.titlesize": 8, "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans",
        "mathtext.it": "Liberation Sans:italic", "mathtext.bf": "Liberation Sans:bold",
        "axes.linewidth": 0.6, "axes.edgecolor": INK2, "axes.labelcolor": INK,
        "xtick.color": INK2, "ytick.color": INK2, "xtick.labelcolor": INK, "ytick.labelcolor": INK,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.minor.width": 0.45, "ytick.minor.width": 0.45,
        "xtick.major.size": 3, "ytick.major.size": 3, "xtick.minor.size": 1.8, "ytick.minor.size": 1.8,
        "xtick.direction": "out", "ytick.direction": "out",
        "axes.spines.top": False, "axes.spines.right": False,
        "lines.linewidth": 1.2, "lines.markersize": 4.2, "patch.linewidth": 0.6,
        "legend.frameon": False, "legend.handlelength": 2.0, "legend.borderaxespad": 0.3,
        "legend.handletextpad": 0.5, "legend.labelspacing": 0.35, "legend.columnspacing": 1.2,
        "savefig.dpi": 600, "figure.dpi": 150, "pdf.fonttype": 42, "ps.fonttype": 42,
        "hatch.linewidth": 0.5, "hatch.color": "white", "text.color": INK,
        "axes.unicode_minus": True, "axes.formatter.use_mathtext": True,
    })

def panel(ax, letter, x=-0.02, y=1.02, ha="right", title=None):
    ax.text(x, y, f"({letter})", transform=ax.transAxes, fontsize=9, fontweight="bold",
            va="bottom", ha=ha, color=INK)
    if title:
        ax.text(x+0.035 if ha=="right" else x+0.06, y, title, transform=ax.transAxes, fontsize=8, va="bottom", ha="left", color=INK)

def save(fig, name, outdir="/home/claude/figs/gge"):
    import os
    from PIL import Image
    os.makedirs(outdir, exist_ok=True)
    fig.savefig(f"{outdir}/{name}.pdf")
    fig.savefig(f"{outdir}/{name}.png", dpi=600)
    im = Image.open(f"{outdir}/{name}.png").convert("RGB")
    im.save(f"{outdir}/{name}.tif", compression="tiff_lzw", dpi=(600, 600))
    plt.close(fig)
