"""Fig. 2 Composition of the database.
(a) vector, exact counts from Table 2. (b,c) box plots: raster interior of the original figure,
re-coloured pixel-exactly (no box, whisker or outlier moved), on rebuilt axes."""
import numpy as np, matplotlib.pyplot as plt, matplotlib.ticker as mt
import jstyle as J, rasterkit as rk
J.use()
S = [f"S{i:02d}" for i in range(1,21)]
ucs = [24,11,13,4,36,0,28,10,10,18,20,8,60,72,9,7,8,15,14,30]
cbr = [12,9,20,0,72,2,0,5,0,0,10,0,0,0,0,0,4,15,0,10]
assert sum(ucs)==397 and sum(cbr)==159
fig = plt.figure(figsize=(J.W2, 5.1))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.08], hspace=0.42, wspace=0.28, left=0.085, right=0.985, top=0.965, bottom=0.075)
ax = fig.add_subplot(gs[0, :])
x = np.arange(20); w = 0.38
ax.bar(x-w/2, ucs, w, color=J.TEAL, edgecolor="white", linewidth=0.4, label="UCS (397 records, 19 studies)", zorder=2)
ax.bar(x+w/2, cbr, w, color=J.TERRA, edgecolor="white", linewidth=0.4, hatch="////", label="CBR (159 records, 10 studies)", zorder=2)
for xi,(u,c) in enumerate(zip(ucs,cbr)):
    if u==0: ax.text(xi-w/2, 0.8, "–", ha="center", va="bottom", fontsize=8, color=J.MUTED)
    if c==0: ax.text(xi+w/2, 0.8, "–", ha="center", va="bottom", fontsize=8, color=J.MUTED)
ax.set_xticks(x, S, rotation=90); ax.set_xlim(-0.7, 19.7)
ax.set_ylabel("Records per source study"); ax.set_ylim(0, 76); ax.yaxis.set_major_locator(mt.MultipleLocator(20))
ax.yaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); ax.set_axisbelow(True)
ax.tick_params(axis="x", length=0, pad=3)
ax.legend(loc="upper left", bbox_to_anchor=(0.255, 1.0), ncol=1)
J.panel(ax, "a", x=-0.055, ha="left")

a = rk.load("../raw/image2.png")
def logax(ax, lo, hi):
    ax.yaxis.set_major_locator(mt.FixedLocator(range(int(np.floor(lo)), int(np.ceil(hi))+1)))
    ax.yaxis.set_major_formatter(mt.FuncFormatter(lambda v,p: rf"$10^{{{int(round(v))}}}$"))
    minors = [np.log10(k)+d for d in range(int(np.floor(lo))-1, int(np.ceil(hi))+1) for k in range(2,10)]
    ax.yaxis.set_minor_locator(mt.FixedLocator([m for m in minors if lo<=m<=hi]))
    ax.set_ylim(lo, hi)

def raster_panel(ax, box, xt_px, xt_val, yt_px, yt_val, mapping, xlim_px, ylim_px):
    xm = rk.fit(xt_px, xt_val); ym = rk.fit(yt_px, yt_val)
    assert xm[2] < 1.0 and ym[2] < 1.0, (xm, ym)
    x0,y0,x1,y1 = box
    sub = rk.crop(a, *box)
    rec, _ = rk.recolor(sub, mapping, neutral_map=rk.ink_neutral())
    ext = rk.extent(x0,y0,x1,y1, xm[:2], ym[:2])
    ax.imshow(rec, extent=ext, aspect="auto", interpolation="lanczos", zorder=1)
    f = lambda p, m: m[0]*p+m[1]
    ax.set_xlim(f(xlim_px[0], xm), f(xlim_px[1], xm)); ax.set_ylim(f(ylim_px[1], ym), f(ylim_px[0], ym))
    return xm, ym

# (b) UCS by biopolymer family: axes px x 161..852, y 733..1226
axb = fig.add_subplot(gs[1, 0])
mp = {rk.OLD["blue"]: J.TEAL, rk.OLD["verm"]: J.TEAL, rk.OLD["green"]: J.TEAL, rk.OLD["yellow"]: J.TEAL}
xm, ym = raster_panel(axb, (161, 733, 852, 1226), [246,419,592,765], [0,1,2,3], [782,982,1182], [4,3,2], mp, (159,852), (733,1228))
logax(axb, *axb.get_ylim())
axb.set_xticks([0,1,2,3], ["Guar gum\n174", "Xanthan gum\n130", "Lignin\n77", "Chitosan\n16"])
axb.set_ylabel("UCS (kPa)"); axb.tick_params(axis="x", length=0)
J.panel(axb, "b", x=-0.12, ha="left")
# (c) CBR by moisture condition: axes px x 1061..1753, y 733..1226
axc = fig.add_subplot(gs[1, 1])
mp = {rk.OLD["sky"]: J.TERRA, rk.OLD["blue"]: J.TERRA}
xm, ym = raster_panel(axc, (1061, 733, 1753, 1226), [1175,1406,1636], [0,1,2], [776,991,1206], [2,1,0], mp, (1059,1753), (733,1228))
logax(axc, *axc.get_ylim())
axc.set_xticks([0,1,2], ["Unsoaked\n73", "Soaked\n62", "Not stated\n24"])
axc.set_ylabel("CBR (%)"); axc.tick_params(axis="x", length=0)
J.panel(axc, "c", x=-0.12, ha="left")
J.save(fig, "Fig02")
