"""Fig. 1 Study workflow (schematic; content identical to the original figure)."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
import jstyle as J
J.use()
fig = plt.figure(figsize=(J.W2, 3.35)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 48); ax.axis("off")
TINT = {J.INK: "#F1F2F3", J.TEAL: "#EAF4F2", J.TERRA: "#F8EEE9"}
stages = [
 (1, "Data", J.INK, ["Open database, 20 studies", "UCS: 397 rec., 19 studies", "CBR: 159 rec., 10 studies", "Source DOIs checked"]),
 (2, "Audit", J.INK, ["Duplicates, ranges", "Units, censoring", "Missingness", "Shared-author groups", "Study identifiability"]),
 (3, "ML benchmark", J.TEAL, ["15 models, 3 seed sets", "Random 5-fold split (×5)", "Leave-one-study-out", "Nested grouped tuning", "Feature-order, flag tests"]),
 (4, "Statistics", J.TEAL, ["Paired tests (Holm)", "Influence analysis", "Variance components", "Local calibration", "External check"]),
 (5, "FE models", J.TERRA, ["OpenSeesPy 3D bricks", "UCS: closed-form", "  verification", "CBR: 4 mesh levels,", "  5 parameter sets"]),
 (6, "FE uncertainty", J.TERRA, ["GCI, Richardson", "Axisymmetric reference", "Dilation, yield cone", "Hardening, geometry", "Surrogate audit"]),
 (7, "UCS–CBR link", J.TERRA, ["Calibration surface", "Identifiability of φ, κ", "LOSO vs power law", "  and training mean", "FE-informed networks"]),
 (8, "Conclusions", J.INK, ["Transfers: relative effects", "Does not transfer:", "  study level, φ", "Data still needed"]),
]
W, H, gap = 22.2, 19.0, 1.6; x0 = 5.6
pos = {}
for k, (n, title, col, lines) in enumerate(stages):
    r, c = divmod(k, 4)
    x = x0 + c * (W + gap); y = 26.5 - r * (H + 4.5)
    pos[n] = (x, y)
    filled = n == 8
    ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="square,pad=0", fc=TINT[col], ec="none", zorder=1))
    ax.add_patch(FancyBboxPatch((x, y + H - 0.55), W, 0.55, boxstyle="square,pad=0", fc=col, ec="none", zorder=2))
    ax.add_patch(Circle((x + 2.0, y + H - 3.0), 1.45, fc=col, ec="none", zorder=3))
    ax.text(x + 2.0, y + H - 3.05, str(n), ha="center", va="center", color="white", fontsize=8, fontweight="bold", zorder=4)
    ax.text(x + 4.2, y + H - 3.05, title, ha="left", va="center", fontsize=8, fontweight="bold", color=J.INK, zorder=4)
    for i, s in enumerate(lines):
        ax.text(x + 1.2 if not s.startswith("  ") else x + 1.2, y + H - 6.6 - i * 2.45, ("· " + s) if not s.startswith("  ") else "   " + s.strip(),
                ha="left", va="center", fontsize=8, color=J.INK2, zorder=4)
def arrow(p, q, **kw):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=7, lw=0.8, color=J.INK2, shrinkA=0, shrinkB=0, zorder=5, **kw))
for a_, b_ in [(1,2),(2,3),(3,4),(5,6),(6,7),(7,8)]:
    (xa, ya), (xb, yb) = pos[a_], pos[b_]
    arrow((xa + W + 0.3, ya + H/2), (xb - 0.3, yb + H/2))
(x1, y1), (x5, y5) = pos[1], pos[5]
arrow((x1 + W/2, y1 - 0.3), (x5 + W/2, y5 + H + 0.3))
(x4, y4), (x8, y8) = pos[4], pos[8]
arrow((x4 + W/2, y4 - 0.3), (x8 + W/2, y8 + H + 0.3))
ax.text(2.6, pos[1][1] + H/2, "Data-driven benchmark", rotation=90, ha="center", va="center", fontsize=8, color=J.INK2, fontweight="bold")
ax.text(2.6, pos[5][1] + H/2, "Mechanics (FE)", rotation=90, ha="center", va="center", fontsize=8, color=J.INK2, fontweight="bold")
J.save(fig, "Fig01")
