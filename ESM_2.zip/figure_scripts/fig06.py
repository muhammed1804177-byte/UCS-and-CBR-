"""Fig. 6 Heterogeneity of LOSO errors (digitized; data/fig06ab_digitized.csv, fig06c_digitized.csv)."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, matplotlib.ticker as mt
import jstyle as J
J.use()
d = pd.read_csv("../data/fig06ab_digitized.csv"); c = pd.read_csv("../data/fig06c_digitized.csv")
fig = plt.figure(figsize=(J.W2, 5.9))
gs = fig.add_gridspec(2, 2, height_ratios=[1.25, 1], width_ratios=[1.15, 1], hspace=0.36, wspace=0.30,
                      left=0.085, right=0.985, top=0.945, bottom=0.075)
neg = lambda v, p: f"{v:.1f}".replace("-", "−")
for k, (tgt, lab) in enumerate([("UCS", "a"), ("CBR", "b")]):
    ax = fig.add_subplot(gs[0, k]); q = d[d.target == tgt].reset_index(drop=True)
    y = np.arange(len(q))[::-1]
    ax.axvline(0, color=J.INK2, lw=0.6, zorder=1)
    ax.hlines(y, q.tm, q.svr, color=J.GREY_L, lw=1.4, zorder=2)
    ax.plot(q.tm, y, "s", color=J.TERRA, ms=4.2, mec="white", mew=0.5, zorder=3, label="Training mean")
    ax.plot(q.svr, y, "o", color=J.TEAL, ms=4.6, mec="white", mew=0.5, zorder=4, label="SVR")
    ax.set_yticks(y, q.study); ax.tick_params(axis="y", length=0)
    ax.set_ylim(-0.7, len(q) - 0.3)
    ax.set_xlabel(f"Study offset, predicted − observed (log$_{{10}}$ {tgt})")
    ax.xaxis.set_major_locator(mt.MultipleLocator(0.5 if tgt == "UCS" else 0.2))
    ax.xaxis.set_major_formatter(mt.FuncFormatter(neg if tgt == "UCS" else (lambda v, p: f"{v:.1f}".replace("-", "−"))))
    ax.xaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); ax.set_axisbelow(True)
    J.panel(ax, lab, x=-0.16, ha="left", y=1.0)
    ax.text(-0.05, 1.0, f"{tgt}, {len(q)} held-out studies", transform=ax.transAxes, fontsize=8, va="bottom")
    if k == 0: ax.legend(loc="upper left", handletextpad=0.2)
ax = fig.add_subplot(gs[1, :])
y = np.arange(len(c))[::-1]
isrule = c.model.str.startswith("Rule")
ax.axvline(0, color=J.INK2, lw=0.6)
r = c[isrule].iloc[0]
ax.axvspan(r.lo, r.hi, color=J.TERRA, alpha=0.08, lw=0, zorder=0)
ax.axvline(r.rho, color=J.TERRA, lw=0.7, ls=(0, (4, 2)), zorder=0)
for i, row in c.iterrows():
    col, mk = (J.TERRA, "D") if row.model.startswith("Rule") else (J.TEAL, "o")
    ax.errorbar(row.rho, y[i], xerr=[[row.rho - row.lo], [row.hi - row.rho]], fmt=mk, color=col, ms=4.4, mec="white", mew=0.5,
                elinewidth=0.9, capsize=1.8, zorder=3)
labels = ["Rule: dose + curing (no training)" if m.startswith("Rule") else m for m in c.model]
ax.set_yticks(y, labels); ax.tick_params(axis="y", length=0)
ax.get_yticklabels()[0].set_fontweight("bold")
ax.set_xlim(-0.1, 1.0); ax.set_ylim(-0.7, len(c) - 0.3)
ax.set_xlabel("Within-study Spearman ρ, UCS (mean over 18 held-out studies, 95% CI)")
ax.xaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); ax.set_axisbelow(True)
J.panel(ax, "c", x=-0.215, ha="left", y=1.0)
fig.axes[-1].set_position([0.305, 0.075, 0.68, 0.335])
J.save(fig, "Fig06")
