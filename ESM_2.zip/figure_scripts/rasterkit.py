"""Pixel-exact tools for re-presenting raster-only figure content.
No data value is moved: pixels are recoloured by key-colour blending, and colormapped fields
are inverted to their normalized scalar and re-mapped."""
import numpy as np
from PIL import Image
import matplotlib as mpl

def load(path):
    return np.asarray(Image.open(path).convert("RGB")).astype(float) / 255.0

def dark_mask(a, thr=0.35):
    return a.max(-1) < thr

def spines(a, box, thr=0.35, minfrac=0.6):
    """box=(x0,y0,x1,y1) in px. Returns (x_left_spine, y_bottom_spine) as the dark column/row
    with the longest run inside the box."""
    x0, y0, x1, y1 = box
    d = dark_mask(a[y0:y1, x0:x1], thr)
    colsum = d.sum(0); rowsum = d.sum(1)
    xl = x0 + int(np.argmax(colsum)); yb = y0 + int(np.argmax(rowsum))
    return xl, yb, colsum.max() / (y1 - y0), rowsum.max() / (x1 - x0)

def ticks_y(a, xspine, y0, y1, side=-1, L=(2, 9), thr=0.45):
    """rows of tick marks just outside a vertical spine (side=-1 left). Returns centre rows."""
    xs = [xspine + side * k for k in range(L[0], L[1])]
    d = np.all(dark_mask(a[y0:y1][:, xs], thr), axis=1)
    return _runs(d, y0)

def ticks_x(a, yspine, x0, x1, side=1, L=(2, 9), thr=0.45):
    ys = [yspine + side * k for k in range(L[0], L[1])]
    d = np.all(dark_mask(a[ys][:, x0:x1], thr), axis=0)
    return _runs(d, x0)

def _runs(d, off):
    out = []; i = 0; n = len(d)
    while i < n:
        if d[i]:
            j = i
            while j < n and d[j]: j += 1
            out.append(off + (i + j - 1) / 2.0); i = j
        else: i += 1
    return out

def fit(pix, vals):
    """linear map px->value; returns (slope, intercept, max residual in px)."""
    pix = np.asarray(pix, float); vals = np.asarray(vals, float)
    A = np.vstack([pix, np.ones_like(pix)]).T
    (m, c), *_ = np.linalg.lstsq(A, vals, rcond=None)
    res = np.abs((vals - c) / m - pix).max()
    return m, c, res

def recolor(a, mapping, white=(1, 1, 1), neutral_map=None, sat_thr=0.08):
    """Each non-white pixel is modelled as t*K + (1-t)*white for the nearest key colour K
    (old palette) and rewritten as t*K' + (1-t)*white. Neutral (grey/black) pixels are left
    as is unless neutral_map is given."""
    W = np.array(white)
    keys = np.array([mpl.colors.to_rgb(k) for k in mapping]); new = np.array([mpl.colors.to_rgb(v) for v in mapping.values()])
    H, Wd, _ = a.shape; P = a.reshape(-1, 3)
    sat = P.max(1) - P.min(1)
    out = P.copy()
    idx = np.where(sat > sat_thr)[0]
    p = P[idx]
    best = np.full(len(idx), np.inf); bk = np.zeros(len(idx), int); bt = np.zeros(len(idx))
    for k, K in enumerate(keys):
        d = K - W; t = np.clip(((p - W) @ d) / (d @ d), 0, 1)
        r = np.linalg.norm(p - (W + t[:, None] * d), axis=1)
        m = r < best; best[m] = r[m]; bk[m] = k; bt[m] = t[m]
    out[idx] = W + bt[:, None] * (new[bk] - W)
    if neutral_map is not None:
        nid = np.where(sat <= sat_thr)[0]
        out[nid] = neutral_map(P[nid])
    return out.reshape(H, Wd, 3), best.reshape(-1) if False else best

def invert_cmap(a, cmap="viridis", n=512, bg=(1, 1, 1)):
    """Invert a colormapped raster: each pixel = s*C(v) (dark mesh-line blend, s<=1) or
    t*C(v)+(1-t)*bg (antialias to background). Returns v (0..1), weight w, mode (0 dark-blend,
    1 bg-blend), residual, bgmask."""
    C = mpl.colormaps[cmap](np.linspace(0, 1, n))[:, :3]
    H, Wd, _ = a.shape; P = a.reshape(-1, 3); B = np.array(bg)
    isbg = np.linalg.norm(P - B, axis=1) < 0.02
    idx = np.where(~isbg)[0]; p = P[idx]
    best = np.full(len(idx), np.inf); bv = np.zeros(len(idx)); bw = np.ones(len(idx)); bm = np.zeros(len(idx), int)
    for i in range(0, n):
        c = C[i]
        s = np.clip((p @ c) / (c @ c), 0, 1.0)            # dark blend
        r1 = np.linalg.norm(p - s[:, None] * c, axis=1)
        d = c - B; t = np.clip(((p - B) @ d) / (d @ d), 0, 1)  # background blend
        r2 = np.linalg.norm(p - (B + t[:, None] * d), axis=1)
        for r, w, mode in ((r1, s, 0), (r2, t, 1)):
            m = r < best; best[m] = r[m]; bv[m] = i / (n - 1); bw[m] = w[m]; bm[m] = mode
    v = np.zeros(len(P)); w = np.zeros(len(P)); mode = np.ones(len(P), int); res = np.zeros(len(P))
    v[idx] = bv; w[idx] = bw; mode[idx] = bm; res[idx] = best
    return v.reshape(H, Wd), w.reshape(H, Wd), mode.reshape(H, Wd), res.reshape(H, Wd), isbg.reshape(H, Wd)

def remap_field(a, newcmap, cmap="viridis", bg=(1, 1, 1), dark=(0.0, 0.0, 0.0)):
    v, w, mode, res, isbg = invert_cmap(a, cmap, bg=bg)
    Cn = newcmap(v)[..., :3]
    B = np.array(bg); out = np.empty_like(a)
    m0 = mode == 0
    out[m0] = w[m0][:, None] * Cn[m0]
    m1 = ~m0
    out[m1] = B + w[m1][:, None] * (Cn[m1] - B)
    out[isbg] = B
    return out, v, res

def save_rgb(arr, path, dpi=300):
    Image.fromarray((np.clip(arr, 0, 1) * 255).round().astype(np.uint8)).save(path, dpi=(dpi, dpi))

OLD = {"blue":"#0072B2","verm":"#D55E00","green":"#009E73","yellow":"#E69F00","pink":"#CC79A7","sky":"#56B4E9"}

def ink_neutral(target="#2B3035"):
    T = np.array(mpl.colors.to_rgb(target))
    def f(p):
        k = 1 - p.mean(1, keepdims=True)          # darkness 0..1
        return 1 - k * (1 - T)
    return f

def crop(a, x0, y0, x1, y1):
    return a[y0:y1+1, x0:x1+1]

def extent(x0, y0, x1, y1, xm, ym):
    """pixel crop box -> data extent [left,right,bottom,top]; xm/ym = (slope, intercept) px->data"""
    fx = lambda p: xm[0]*p + xm[1]; fy = lambda p: ym[0]*p + ym[1]
    return [fx(x0-0.5), fx(x1+0.5), fy(y1+0.5), fy(y0-0.5)]

def whiten(a, box):
    x0,y0,x1,y1 = box; a = a.copy(); a[y0:y1+1, x0:x1+1] = 1.0; return a

def remap_field_with_white_lines(a, newcmap, line_color, cmap="viridis", min_bg_area=2000):
    """As remap_field, but white line art drawn over the field (e.g. dashed contours) is distinguished from
    the white background/undefined region by connectivity and re-inked in line_color."""
    from scipy import ndimage as ndi
    v, w, mode, res, isbg = invert_cmap(a, cmap)
    lab, n = ndi.label(isbg)
    H, W_ = isbg.shape
    big = np.zeros_like(isbg)
    for i in range(1, n + 1):
        m = lab == i
        ys, xs = np.where(m)
        touches = ys.min() == 0 or xs.max() == W_ - 1 or ys.max() == H - 1 or xs.min() == 0
        if m.sum() >= min_bg_area and touches: big |= m
    dash = isbg & ~big
    near_dash = ndi.binary_dilation(dash, iterations=2) & ~ndi.binary_dilation(big, iterations=2)
    Cn = newcmap(v)[..., :3]; L = np.array(mpl.colors.to_rgb(line_color)); B = np.ones(3)
    out = np.empty_like(a)
    m0 = mode == 0; out[m0] = w[m0][:, None] * Cn[m0]
    m1 = ~m0
    tgt = np.where(near_dash[..., None], L, B)
    out[m1] = tgt[m1] + w[m1][:, None] * (Cn[m1] - tgt[m1])
    out[big] = B; out[dash] = L
    return out, v, res
