"""Fig. 8 3D UCS model. (a) FE render: viridis field inverted to its normalized scalar and re-mapped to the
journal sequential map (same vmin/vmax as the original colorbar, 180-850 kPa); (b) original raster curves,
recoloured; (c) exact values from Table 8 / text."""
import numpy as np, matplotlib.pyplot as plt, matplotlib as mpl, matplotlib.ticker as mt
import jstyle as J, rasterkit as rk, rpanel as R
J.use()
a = rk.load("../raw/image8.png")
fig = plt.figure(figsize=(J.W2, 3.2))
axa = fig.add_axes([0.0, 0.10, 0.20, 0.80]); axcb = fig.add_axes([0.205, 0.16, 0.013, 0.68])
axb = fig.add_axes([0.355, 0.165, 0.29, 0.745]); axc = fig.add_axes([0.745, 0.165, 0.245, 0.745])
# (a) render
x0, y0, x1, y1 = 150, 215, 340, 595
sub = rk.crop(a, x0, y0, x1, y1)
rem, v, res = rk.remap_field(sub, J.SEQ)
axa.imshow(rem, interpolation="lanczos"); axa.set_axis_off(); axa.set_aspect("equal")
# colorbar calibration from original: ticks 800/600/400/200 at rows 234/348/463/577; bar rows 205.5..588.5
m, c, r_ = rk.fit([234, 348, 463, 577], [800, 600, 400, 200]); vmax = m * 205.5 + c; vmin = m * 588.5 + c
norm = mpl.colors.Normalize(vmin, vmax)
cb = fig.colorbar(mpl.cm.ScalarMappable(norm, J.SEQ), cax=axcb); cb.set_ticks([200, 400, 600, 800])
cb.outline.set_linewidth(0.5); axcb.tick_params(length=2.5, width=0.5, labelsize=8)
cb.set_label("von Mises stress (kPa)", fontsize=8, labelpad=3)
axa.text(0.04, 1.02, "(a)", transform=axa.transAxes, fontsize=8.5, fontweight="bold", va="bottom")
axa.text(0.04, -0.01, "Rough platens, 2% axial\nstrain (deformation ×3)", transform=axa.transAxes, fontsize=8, va="top", color=J.MUTED)
# (b) curves
pre = lambda s, o: rk.whiten(s, (770 - o[0], 86 - o[1], 1258 - o[0], 188 - o[1]))
R.raster_axes(axb, a, (766, 77, 1258, 716), ([766, 962, 1159], [0, 2, 4]), ([153, 247, 340, 434, 528, 622, 716], [3.0, 2.5, 2.0, 1.5, 1.0, 0.5, 0.0]),
              mapping={rk.OLD["blue"]: J.TEAL}, neutral=rk.ink_neutral(), pre=pre)
axb.set_xlabel(r"Normalized strain, $\varepsilon E/\mathrm{UCS}_{\mathrm{MC}}$"); axb.set_ylabel(r"Axial stress / UCS$_{\mathrm{MC}}$")
axb.yaxis.set_major_locator(mt.MultipleLocator(0.5)); axb.set_xticks([0, 1, 2, 3, 4, 5])
from matplotlib.lines import Line2D
axb.legend([Line2D([], [], color=J.TEAL, lw=1.6), Line2D([], [], color=J.INK, lw=1.0, ls="--"), Line2D([], [], color="#B3B3B3", lw=0.8)],
           ["Representative case", "Mohr–Coulomb closed form", "32 Latin-hypercube runs"], loc="upper left", fontsize=8)
J.panel(axb, "b", x=-0.02, ha="right", y=1.0)
# (c) exact
el = np.array([128, 468, 1296])
qmc = 2 * 150 * np.cos(np.radians(25)) / (1 - np.sin(np.radians(25)))
smooth = 1 + np.array([-2.5, -1.1, -0.6]) / 100
rough = np.array([693, 599, 549]) / qmc
axc.axhline(1.0, color=J.INK2, lw=0.6, ls=(0, (1, 1.5)))
axc.plot(el, rough, "--s", color=J.TERRA, ms=4.2, mec="white", mew=0.5, label="Rough (stress at 3% strain)")
axc.plot(el, smooth, "-o", color=J.TEAL, ms=4.4, mec="white", mew=0.5, label="Smooth (peak)")
for e_, s_ in zip(el, smooth): axc.text(e_ * 1.06, s_ - 0.035, f"{(s_-1)*100:+.1f}%".replace("-", "−"), ha="center", va="top", fontsize=8, color=J.INK2)
for e_, r__, raw, ha in zip(el, rough, [693, 599, 549], ["left", "left", "center"]):
    axc.text(e_ * (1.08 if ha == "left" else 1.0), r__ + (0.012 if ha == "left" else -0.03), f"{raw} kPa", ha=ha, va="bottom" if ha == "left" else "top", fontsize=8, color=J.INK2)
axc.set_xscale("log"); axc.set_xticks(el, ["128", "468", "1,296"]); axc.xaxis.set_minor_locator(mt.NullLocator())
axc.set_xlim(95, 2200); axc.set_ylim(0.88, 1.80); axc.yaxis.set_major_locator(mt.FixedLocator([0.9,1.0,1.1,1.2,1.3,1.4,1.5]))
axc.set_xlabel("Elements (quarter model)"); axc.set_ylabel(r"UCS$_{\mathrm{FE}}$ / UCS$_{\mathrm{MC}}$")
axc.text(2100, 1.0 + 0.012, f"closed form {qmc:.0f} kPa", ha="right", va="bottom", fontsize=8, color=J.MUTED)
axc.legend(loc="upper right", fontsize=8, bbox_to_anchor=(1.03, 1.02), handlelength=1.6)
J.panel(axc, "c", x=-0.02, ha="right", y=1.0)
J.save(fig, "Fig08")
print("field inversion residual: median %.4f, 99th pct %.4f" % (np.median(res), np.percentile(res, 99)), "vmin/vmax", round(vmin, 1), round(vmax, 1))
