import rasterkit as rk, numpy as np, sys
def report(img, box, name=""):
    a = rk.load(img)
    xl, yb, fy, fx = rk.spines(a, box)
    x0,y0,x1,y1 = box
    # extents of spines
    col = rk.dark_mask(a[y0:y1, xl]); rows = np.where(col)[0]
    row = rk.dark_mask(a[yb, x0:x1]); cols = np.where(row)[0]
    print(f"{name}: left spine x={xl} (y {y0+rows.min()}..{y0+rows.max()}), bottom spine y={yb} (x {x0+cols.min()}..{x0+cols.max()})")
    print("  yticks:", [round(v,1) for v in rk.ticks_y(a, xl, y0, y1)])
    print("  xticks:", [round(v,1) for v in rk.ticks_x(a, yb, x0, x1)])
if __name__ == "__main__":
    img = sys.argv[1]; box = tuple(map(int, sys.argv[2:6])); report(img, box)
