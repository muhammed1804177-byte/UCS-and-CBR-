"""Fig. 4 Per-study RMSE under LOSO: SVR, training mean, range over 15 models (digitized; see data/fig04_data.csv)."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, matplotlib.ticker as mt
import jstyle as J
J.use()
d = pd.read_csv("../data/fig04_data.csv")
fig, axs = plt.subplots(2, 1, figsize=(J.W2, 4.6), gridspec_kw=dict(height_ratios=[1, 1], hspace=0.42))
fig.subplots_adjust(left=0.085, right=0.985, top=0.88, bottom=0.075)
means = {"a": (0.435, 0.413), "b": (0.436, 0.392)}   # Table 5: SVR, training mean (mean per-study RMSE)
for ax, p, lab in zip(axs, "ab", ["UCS", "CBR"]):
    q = d[d.panel == p].reset_index(drop=True); x = np.arange(len(q))
    ax.vlines(x, q.range_lo, q.range_hi, color=J.GREY_L, lw=5.5, zorder=1, label="Range over 15 models")
    ax.plot(x - 0.13, q.tm, "s", color=J.TERRA, ms=4.4, mec="white", mew=0.5, zorder=3, label="Training mean")
    ax.plot(x + 0.13, q.svr, "o", color=J.TEAL, ms=4.8, mec="white", mew=0.5, zorder=3, label="SVR")
    s, t = means[p]
    ax.axhline(t, color=J.TERRA, lw=0.8, ls=(0, (4, 2)), zorder=0, label="Mean per-study RMSE, training mean"); ax.axhline(s, color=J.TEAL, lw=0.8, ls=(0, (1, 1.5)), zorder=0, label="Mean per-study RMSE, SVR")
    ax.set_xticks(x, q.study); ax.set_xlim(-0.6, len(q) - 0.4)
    ax.tick_params(axis="x", length=0, pad=3)
    ax.set_ylabel(f"Per-study RMSE\n(log$_{{10}}$ {lab})")
    ax.set_ylim(0, 1.22 if p == "a" else 0.92); ax.yaxis.set_major_locator(mt.MultipleLocator(0.2))
    ax.yaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); ax.set_axisbelow(True)
    J.panel(ax, p, x=-0.075, ha="left", y=1.0)
    ax.text(-0.025, 1.0, f"{lab}, {len(q)} held-out studies", transform=ax.transAxes, fontsize=8, va="bottom", ha="left")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=3, bbox_to_anchor=(0.53, 1.01), columnspacing=1.0)
J.save(fig, "Fig04")
