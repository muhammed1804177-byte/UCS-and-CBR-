"""Fig. 9 CBR mesh study. (a) original raster curves, recoloured (standard loads redrawn exactly);
(b,c) exact values: CBR per mesh level (first-version Table 3 = Table 8 endpoints), graded series from text."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, matplotlib.ticker as mt
from matplotlib.lines import Line2D
import jstyle as J, rasterkit as rk, rpanel as R
J.use()
a = rk.load("../raw/image9.png")
t = pd.read_csv("../data/table_mesh.csv")
# consistency checks against Table 8 (L1/extrapolated) and text
assert np.allclose((t.L1 / t.extrap).round(2), [1.08, 1.17, 1.25, 1.61, 1.89], atol=0.02)
fig = plt.figure(figsize=(J.W2, 5.3))
axa = fig.add_axes([0.085, 0.57, 0.36, 0.39]); axb = fig.add_axes([0.585, 0.57, 0.40, 0.39]); axc = fig.add_axes([0.255, 0.075, 0.33, 0.37])
G = ["#BFC4C8", "#8E959B", "#5D646B", J.INK]
def pre(s, o):
    s = rk.whiten(s, (150 - o[0], 82 - o[1], 445 - o[0], 335 - o[1]))            # old legend
    for (px, py) in [(340, 395), (536, 239)]:                                      # old standard-load squares
        s = rk.whiten(s, (px - 14 - o[0], py - 14 - o[1], px + 14 - o[0], py + 14 - o[1]))
    return s
mp = {rk.OLD["blue"]: G[0], rk.OLD["verm"]: G[1], rk.OLD["green"]: G[2], rk.OLD["yellow"]: G[3]}
R.raster_axes(axa, a, (144, 76, 554, 701), ([144, 301, 458], [0, 2, 4]), ([123, 239, 354, 470, 585, 701], [25, 20, 15, 10, 5, 0]),
              mapping=mp, neutral=rk.ink_neutral(J.TEAL), pre=pre)
axa.plot([2.5, 5.0], [13.24, 19.96], "s", ms=4.6, mfc="white", mec=J.TERRA, mew=1.0, zorder=4)
axa.annotate("Standard loads\n(BS 1377)", (5.0, 19.96), (3.75, 16.4), fontsize=8, color=J.INK2, ha="center", va="center",
             arrowprops=dict(arrowstyle="-", lw=0.5, color=J.TERRA, shrinkA=1, shrinkB=3))
axa.set_xticks([0, 1, 2, 3, 4, 5]); axa.yaxis.set_major_locator(mt.MultipleLocator(5)); axa.set_ylim(0, 34)
axa.set_xlabel("Penetration (mm)"); axa.set_ylabel("Plunger load (kN)")
lines = [Line2D([], [], color=G[0], lw=1.2), Line2D([], [], color=G[1], lw=1.2, ls="--"), Line2D([], [], color=G[2], lw=1.2, ls="-."),
         Line2D([], [], color=G[3], lw=1.2, ls=":"), Line2D([], [], color=J.TEAL, lw=1.0, ls=":", marker="o", ms=3, mfc="white")]
axa.legend(lines, ["L0, 168 el.", "L1, 456 el. (campaign)", "L2, 1,248 el.", "L3, 2,640 el.", "L3, graded to plunger edge"], loc="upper left", fontsize=8, handlelength=2.0, bbox_to_anchor=(-0.01, 1.03))
J.panel(axa, "a", x=-0.02, ha="right", y=1.03)
# (b) convergence: 3D uniform meshes vs axisymmetric reference, both normalized by the converged axisymmetric value
import json
ax3 = json.load(open("../data/axi_gci_summary.json"))
cols = {"Stiff frictional": J.BLUE, "Strong stiff": J.SAGE, "Cohesive soft": J.INK, "Representative": J.TEAL, "Weak": J.TERRA}
mks = {"Stiff frictional": "o", "Strong stiff": "s", "Cohesive soft": "^", "Representative": "D", "Weak": "v"}
h3 = np.array([1.0, 0.5, 0.25, 0.125])           # relative element size of the 3D family (L0..L3, ratio ~2 per level in elements^(1/3)? see note)
el3 = np.array([168, 456, 1248, 2640]); h3 = (el3[0] / el3) ** (1 / 3)
axb.axhline(1.0, color=J.INK2, lw=0.7, ls=(0, (1, 1.5)))
for r in ax3:
    nm = r["name"]; ref = r["ext"]
    t3 = t[t.name == nm].iloc[0]
    y3 = np.array([t3.L0, t3.L1, t3.L2, t3.L3]) / ref
    nel = np.array(r["nel"]); ha = (nel[0] / nel) ** 0.5
    axb.plot(ha, np.array(r["CBR"]) / ref, ls="-", marker=mks[nm], color=cols[nm], ms=4.2, mec="white", mew=0.5, lw=1.1)
    axb.plot(h3, y3, ls=":", marker=mks[nm], color=cols[nm], ms=4.2, mfc="white", mec=cols[nm], mew=0.9, lw=1.0)
axb.set_xscale("log"); axb.invert_xaxis()
axb.set_xticks([1, 0.5, 0.25, 0.125], ["1", "1/2", "1/4", "1/8"]); axb.xaxis.set_minor_locator(mt.NullLocator())
axb.set_xlim(1.25, 0.1); axb.set_ylim(0.9, 2.5); axb.yaxis.set_major_locator(mt.MultipleLocator(0.25))
axb.set_xlabel("Relative element size within each mesh family"); axb.set_ylabel("CBR / converged axisymmetric CBR")
from matplotlib.lines import Line2D
axb.legend([Line2D([], [], color=J.INK2, ls="-", marker="o", ms=4, mec="white"), Line2D([], [], color=J.INK2, ls=":", marker="o", ms=4, mfc="white")],
           ["Axisymmetric Q8 model", "3D quarter model, uniform meshes"], loc="upper right", fontsize=8)
J.panel(axb, "b", x=-0.02, ha="right", y=1.03)
# (c) GCI: 3D vs axisymmetric
plt.rcParams["hatch.color"] = J.INK2
names = [r["name"] for r in sorted(ax3, key=lambda r: r["gci3D"])]
ys = np.arange(len(names))[::-1]
for y_, nm in zip(ys, names):
    r = [q for q in ax3 if q["name"] == nm][0]; row = t[t.name == nm].iloc[0]
    axc.barh(y_ + 0.19, r["gci3D"], 0.36, color="white", edgecolor=cols[nm], hatch="////", lw=0.8, zorder=2)
    axc.barh(y_ - 0.19, r["gci"], 0.36, color=cols[nm], edgecolor="white", lw=0.4, zorder=2)
    axc.text(max(r["gci3D"], 5) + 0.7, y_ + 0.19, f"{r['gci3D']:.1f}", va="center", fontsize=8)
    axc.text(max(r["gci"], 5) + 0.7, y_ - 0.19, f"{r['gci']:.1f}", va="center", fontsize=8)
plt.rcParams["hatch.color"] = J.INK2
axc.axvline(5, color=J.INK, lw=0.8, ls="--", zorder=3)
axc.text(5.4, ys[0] + 0.62, "5% criterion", fontsize=8, ha="left", va="bottom")
labs = [f"{n} (c {c:g}, φ {p:g}°, E {e:g})" for n, c, p, e in [(nm, *t[t.name == nm][["c_kPa", "phi_deg", "E_MPa"]].iloc[0].values) for nm in names]]
axc.set_yticks(ys, labs); axc.tick_params(axis="y", length=0)
axc.set_xlim(0, 40); axc.set_ylim(-0.7, len(names) - 0.2); axc.set_xlabel("GCI of finest mesh (%)")
axc.xaxis.set_major_locator(mt.MultipleLocator(10)); axc.xaxis.grid(True, color=J.GREY_XL, lw=0.5, zorder=0); axc.set_axisbelow(True)
from matplotlib.patches import Patch
fig.legend([Patch(facecolor="white", edgecolor=J.INK2, hatch="////"), Patch(facecolor=J.INK2)], ["3D quarter model (L1–L3)", "Axisymmetric Q8 (levels 2–8)"],
           loc="center left", bbox_to_anchor=(0.66, 0.30), fontsize=8, title="Panel (c)", title_fontsize=8)
J.panel(axc, "c", x=-0.02, ha="right", y=1.03)
J.save(fig, "Fig09")
