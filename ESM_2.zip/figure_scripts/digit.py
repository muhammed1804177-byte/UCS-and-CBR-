import numpy as np, rasterkit as rk
from scipy import ndimage as ndi
import matplotlib as mpl
def color_mask(a, hexc, tol=0.12):
    c = np.array(mpl.colors.to_rgb(hexc)); return np.linalg.norm(a - c, axis=-1) < tol
def blobs(mask, minarea=20):
    lab, n = ndi.label(mask)
    out = []
    for i in range(1, n+1):
        ys, xs = np.where(lab == i)
        if len(ys) < minarea: continue
        out.append(dict(cx=xs.mean(), cy=ys.mean(), area=len(ys), x0=xs.min(), x1=xs.max(), y0=ys.min(), y1=ys.max()))
    return out

def errorbar_v(mask_strip):
    """vertical errorbar in a narrow strip: returns (marker_centre_row, lo_cap_row, hi_cap_row, centre_col)
    marker = rows whose width >= 0.6*max width; caps = extreme wide rows of the line."""
    w = mask_strip.sum(1); rows = np.where(w > 0)[0]
    wmax = w.max(); mrows = np.where(w >= 0.6 * wmax)[0]
    # largest contiguous run of marker rows
    runs = np.split(mrows, np.where(np.diff(mrows) > 1)[0] + 1); run = max(runs, key=len)
    mc = (run[0] + run[-1]) / 2.0
    lw = np.median(w[(w > 0) & (w < 0.6 * wmax)])
    wide = np.where(w >= lw + 3)[0]
    wide = wide[(wide < run[0] - 1) | (wide > run[-1] + 1)]
    lo_rows = wide[wide > run[-1]]; hi_rows = wide[wide < run[0]]
    def endrun(r, last):
        if len(r) == 0: return np.nan
        g = np.split(r, np.where(np.diff(r) > 1)[0] + 1); g = g[-1] if last else g[0]
        return g.mean()
    return mc, endrun(lo_rows, True), endrun(hi_rows, False)
def errorbar_h(mask_strip):
    mc, lo, hi = errorbar_v(mask_strip.T)
    return mc, lo, hi

def vbar_centre_run(mask_strip, mc_row):
    """bar ends from the contiguous run of the centre columns that contains the marker centre."""
    W = mask_strip.shape[1]; c = W // 2
    col = mask_strip[:, c-1:c+2].any(1)
    r = int(round(mc_row)); lo = r; hi = r
    while hi + 1 < len(col) and col[hi + 1]: hi += 1
    while lo - 1 >= 0 and col[lo - 1]: lo -= 1
    return hi, lo   # (bottom row, top row)
