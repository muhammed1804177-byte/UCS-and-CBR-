import numpy as np, matplotlib.ticker as mt
import rasterkit as rk

def raster_axes(ax, a, axbox, xcal, ycal, mapping=None, neutral=None, pre=None, field=None, pad=(2, 2, 0, 2), interp="lanczos", field_lines=None):
    """axbox=(x_left_spine, y_top, x_right, y_bottom_spine) in source px.
    xcal/ycal = (pixel list, value list). Crops the plot interior, recolours it and places it at its
    exact data extent. Returns the (xmap, ymap) px->data fits and the recoloured crop."""
    xl, yt, xr, yb = axbox
    xm = rk.fit(*xcal); ym = rk.fit(*ycal)
    assert xm[2] < 1.0 and ym[2] < 1.0, ("calibration residual too large", xm[2], ym[2])
    x0, y0, x1, y1 = xl + pad[0], yt + pad[2], xr - pad[3] + 1, yb - pad[1]
    sub = rk.crop(a, x0, y0, x1, y1)
    if pre is not None: sub = pre(sub, (x0, y0))
    if field is not None and field_lines is None:
        sub, _, _ = rk.remap_field(sub, field)
    elif field is not None:
        sub, _, _ = rk.remap_field_with_white_lines(sub, field, field_lines)
    if mapping is not None:
        sub, _ = rk.recolor(sub, mapping, neutral_map=neutral)
    ext = rk.extent(x0, y0, x1, y1, xm[:2], ym[:2])
    ax.imshow(sub, extent=ext, aspect="auto", interpolation=interp, zorder=1)
    f = lambda p, m: m[0] * p + m[1]
    ax.set_xlim(f(xl, xm), f(xr, xm)); ax.set_ylim(f(yb, ym), f(yt, ym))
    return xm, ym, sub

def log_ticks(axis, lo, hi, labels=True):
    maj = [k for k in range(int(np.floor(lo)), int(np.ceil(hi)) + 1) if lo - 1e-9 <= k <= hi + 1e-9]
    axis.set_major_locator(mt.FixedLocator(maj))
    axis.set_major_formatter(mt.FuncFormatter(lambda v, p: rf"$10^{{{int(round(v))}}}$" if labels else ""))
    mins = [np.log10(k) + d for d in range(int(np.floor(lo)) - 1, int(np.ceil(hi)) + 1) for k in range(2, 10)]
    axis.set_minor_locator(mt.FixedLocator([m for m in mins if lo <= m <= hi]))
