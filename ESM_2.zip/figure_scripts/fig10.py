"""Fig. 10 UCS-to-CBR link. (a) original calibration-objective field (12 discrete bands) inverted from viridis
and re-mapped band-for-band; colorbar rebuilt with the original band edges and labels; dashed 5% contour kept.
(b) original scatter raster recoloured; RMSE values from Table 9."""
import numpy as np, matplotlib.pyplot as plt, matplotlib as mpl, matplotlib.ticker as mt
from matplotlib.lines import Line2D
import jstyle as J, rasterkit as rk, rpanel as R
J.use()
a = rk.load("../raw/image10.png")
fig = plt.figure(figsize=(J.W2, 3.9))
axa = fig.add_axes([0.08, 0.21, 0.30, 0.72]); axcb = fig.add_axes([0.395, 0.21, 0.016, 0.72]); axb = fig.add_axes([0.6, 0.21, 0.385, 0.72])
R.raster_axes(axa, a, (143, 79, 654, 819), ([144, 272, 399, 526, 654], [1.0, 1.5, 2.0, 2.5, 3.0]),
              ([80, 203, 326, 450, 573, 696, 819], [40, 35, 30, 25, 20, 15, 10]), field=J.SEQ, field_lines=J.INK, pad=(2, 2, 1, 0))
axa.set_xlabel(r"log$_{10}\,\kappa$ = log$_{10}$(E/UCS)"); axa.set_ylabel("Friction angle φ (°)")
axa.set_xticks([1.0, 1.5, 2.0, 2.5, 3.0]); axa.set_yticks([10, 15, 20, 25, 30, 35, 40])
J.panel(axa, "a", x=-0.02, ha="right", y=1.04)
bands_v = [0.039, 0.121, 0.207, 0.290, 0.376, 0.458, 0.540, 0.626, 0.708, 0.791, 0.877, 0.963]   # decoded from original colorbar
cmap = mpl.colors.ListedColormap([J.SEQ(v) for v in bands_v]); norm = mpl.colors.BoundaryNorm(np.arange(13), 12)
cb = fig.colorbar(mpl.cm.ScalarMappable(norm, cmap), cax=axcb, ticks=[0, 2, 4, 6, 8, 10, 12])
cb.set_ticklabels(["0.64", "0.70", "0.77", "0.83", "0.90", "0.96", "1.03"]); cb.outline.set_linewidth(0.5)
axcb.tick_params(length=2.5, width=0.5, labelsize=8); cb.set_label(r"Calibration RMSE (log$_{10}$ CBR)", fontsize=8)
mp = {rk.OLD["blue"]: J.TEAL, rk.OLD["verm"]: J.BLUE, rk.OLD["green"]: J.TERRA}
R.raster_axes(axb, a, (1099, 79, 1738, 819), ([1162, 1369, 1576], [0, 1, 2]), ([80, 304, 528, 752], [3, 2, 1, 0]), mapping=mp, neutral=rk.ink_neutral())
R.log_ticks(axb.xaxis, *axb.get_xlim()); R.log_ticks(axb.yaxis, *axb.get_ylim())
axb.set_xlabel("Measured CBR (%)"); axb.set_ylabel("Predicted CBR (%)")
H = [Line2D([], [], ls="", marker="o", color=J.TEAL, ms=4), Line2D([], [], ls="", marker="s", color=J.BLUE, ms=3.8), Line2D([], [], ls="", marker="^", color=J.TERRA, ms=4),
     Line2D([], [], ls="", marker="o", mfc="none", mec=J.INK2, ms=4)]
fig.legend(H, ["FE chain (UCS → c, E → surrogate)", "Power law", "Training mean", "open: outside surrogate domain"], loc="lower center", fontsize=8, bbox_to_anchor=(0.5, 0.0), ncol=4, columnspacing=1.2, handletextpad=0.3)
J.panel(axb, "b", x=-0.02, ha="right", y=1.04)
J.save(fig, "Fig10")
