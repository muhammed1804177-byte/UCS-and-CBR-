import numpy as np, pandas as pd, json, warnings, prep
import statsmodels.formula.api as smf
from scipy.stats import wilcoxon
warnings.filterwarnings('ignore')
import lmm
def lmm_fp(cols):
    def fp(tr,te):
        if cols: a,b=prep.design(tr,te,cols,indicators=False)
        else: a,b=np.zeros((len(tr),0)),np.zeros((len(te),0))
        keep=a.std(0)>1e-9 if a.shape[1] else np.zeros(0,bool)
        f=lmm.fit_ri(a[:,keep],tr.y.values,tr.study_id.values); return lmm.predict(f,b[:,keep])
    return fp
def svr_fp(cols,ind=True):
    def fp(tr,te):
        a,b=prep.design(tr,te,cols,indicators=ind); return prep.SVR(C=1,epsilon=0.1).fit(a,tr.y).predict(b)
    return fp
def ridge_fp(cols,ind=True):
    from sklearn.linear_model import Ridge
    def fp(tr,te):
        a,b=prep.design(tr,te,cols,indicators=ind); return Ridge(alpha=1).fit(a,tr.y).predict(b)
    return fp
def mean_fp(tr,te): return np.full(len(te),tr.y.mean())
def boot_ci(x,n=10000,seed=1):
    r=np.random.default_rng(seed); return np.percentile([x[r.integers(0,len(x),len(x))].mean() for _ in range(n)],[2.5,97.5])
if __name__=='__main__':
    out={}
    for T in ['UCS','CBR']:
        d=prep.load(T); W=['bio_dose','dose_na','add_dose','tot_dose','curing_days','lnt','dose_lnt']+(['soaked','cond_na'] if T=='CBR' else [])
        FAM=prep.FAM_B+prep.famA(d)
        models={'Training mean':mean_fp,
          'LMM, intercept only':lmm_fp([]),
          'LMM, within-study inputs':lmm_fp(W),
          'LMM, + additive families':lmm_fp(W+FAM),
          'LMM, + soil properties':lmm_fp(W+FAM+prep.SOIL),
          'SVR, all inputs (re-implementation)':svr_fp(prep.feats(d,T)),
          'SVR, no study-constant inputs':svr_fp(W+FAM,ind=False),
          'Ridge, no study-constant inputs':ridge_fp(W+FAM,ind=False)}
        base=None; res={}
        for name,fp in models.items():
            pred=prep.loso(d,fp); ps,R2=prep.metrics(d,pred)
            if base is None: base=ps
            dlt=ps-base
            p=wilcoxon(ps,base).pvalue if name!='Training mean' else np.nan
            ci=boot_ci(dlt) if name!='Training mean' else [np.nan,np.nan]
            res[name]=dict(ps=ps.tolist(),mean=ps.mean(),R2=R2,delta=dlt.mean(),ci=list(ci),p=p,better=int((dlt<0).sum()),n=len(ps))
            print(f'{T} {name:40s} perstudy {ps.mean():.3f} R2 {R2:5.2f} Δ {dlt.mean():+.3f} CI {ci[0]:+.3f} {ci[1]:+.3f} better {(dlt<0).sum()}/{len(ps)} p {p:.3f}',flush=True)
            np.save(f'pred_{T}_{name.split(",")[0].replace(" ","")}_{len(res)}.npy',pred)
        out[T]=res
    json.dump(out,open('lmm_results.json','w'),indent=1,default=float)
