import numpy as np, json, prep, lmm
from scipy.stats import wilcoxon
from run_lmm import svr_fp, boot_ci
rng=np.random.default_rng(2026)
out={}
for T in ['UCS','CBR']:
    d=prep.load(T); W=['bio_dose','dose_na','add_dose','tot_dose','curing_days','lnt','dose_lnt']+(['soaked','cond_na'] if T=='CBR' else [])
    studies=sorted(d.study_id.unique())
    P={'LMM':np.zeros(len(d)),'SVR':np.zeros(len(d))}; VC={}
    for s in studies:
        te=(d.study_id==s).values; tr=d[~te]
        a,b=prep.design(tr,d[te],W,indicators=False); keep=a.std(0)>1e-9
        f=lmm.fit_ri(a[:,keep],tr.y.values,tr.study_id.values); P['LMM'][te]=lmm.predict(f,b[:,keep]); VC[s]=(f['tau2'],f['sigma2'])
        P['SVR'][te]=svr_fp(prep.feats(d,T))(tr,d[te])
    res={}
    for k in [1,2,3]:
        acc={m:{s:[] for s in studies} for m in ['local mean','LMM shift','LMM BLUP','SVR shift']}
        for s in studies:
            idx=np.where(d.study_id==s)[0]; mixes=d.mix.values[idx]; um=np.unique(mixes)
            if len(um)<=k: continue
            tau2,s2=VC[s]
            for _ in range(300):
                pick=rng.choice(um,k,replace=False); cal=idx[np.isin(mixes,pick)]; ev=idx[~np.isin(mixes,pick)]
                y=d.y.values
                ybar=y[cal].mean()
                rmse=lambda p: np.sqrt(((y[ev]-p)**2).mean())
                acc['local mean'][s].append(rmse(np.full(len(ev),ybar)))
                rL=(y[cal]-P['LMM'][cal]).mean(); n=len(cal); w=n*tau2/(n*tau2+s2)
                acc['LMM shift'][s].append(rmse(P['LMM'][ev]+rL)); acc['LMM BLUP'][s].append(rmse(P['LMM'][ev]+w*rL))
                acc['SVR shift'][s].append(rmse(P['SVR'][ev]+(y[cal]-P['SVR'][cal]).mean()))
        ss=[s for s in studies if acc['local mean'][s]]
        ref=np.array([np.mean(acc['local mean'][s]) for s in ss]); res[k]={'n':len(ss),'local mean':ref.mean()}
        for m in ['LMM shift','LMM BLUP','SVR shift']:
            v=np.array([np.mean(acc[m][s]) for s in ss]); dl=v-ref
            res[k][m]=dict(rmse=v.mean(),delta=dl.mean(),ci=boot_ci(dl).tolist(),better=int((dl<0).sum()),p=wilcoxon(v,ref).pvalue)
        print(T,k,len(ss),'local mean %.3f'%ref.mean(),{m:(round(res[k][m]['rmse'],3),round(res[k][m]['delta'],3),[round(x,3) for x in res[k][m]['ci']],res[k][m]['better'],round(res[k][m]['p'],3)) for m in ['LMM shift','LMM BLUP','SVR shift']},flush=True)
    out[T]=res
    w1=[1*VC[s][0]/(1*VC[s][0]+VC[s][1]) for s in studies]
    print(T,'tau2/sigma2 median',np.median([VC[s][0]/VC[s][1] for s in studies]),'ICC median',np.median([VC[s][0]/(VC[s][0]+VC[s][1]) for s in studies]))
json.dump(out,open('calib_results.json','w'),indent=1,default=float)
