import numpy as np
def fit_ri(X,y,g,ridge=1e-3):
    """Random-intercept LMM by REML profile over lambda=tau2/sigma2 (Fuller-Battese transform).
    X without intercept (standardized). Returns beta (incl. intercept), tau2, sigma2."""
    X1=np.c_[np.ones(len(y)),X]; p=X1.shape[1]; N=len(y)
    gs,inv=np.unique(g,return_inverse=True); n=np.bincount(inv)
    P=np.eye(p)*ridge; P[0,0]=0
    best=None
    for lam in np.logspace(-4,3,141):
        th=1-np.sqrt(1/(1+n*lam))
        ym=np.bincount(inv,y)/n; Xm=np.array([np.bincount(inv,X1[:,j])/n for j in range(p)]).T
        ys=y-th[inv]*ym[inv]; Xs=X1-th[inv,None]*Xm[inv]
        A=Xs.T@Xs+P; b=np.linalg.solve(A,Xs.T@ys); r=ys-Xs@b
        s2=r@r/(N-p)
        logdetV=np.sum(np.log(1+n*lam))  # |V|/sigma^2N
        sign,logdetA=np.linalg.slogdet(A)
        ll=-0.5*((N-p)*np.log(s2)+logdetV+logdetA)
        if best is None or ll>best[0]: best=(ll,lam,b,s2)
    ll,lam,b,s2=best
    return dict(beta=b,tau2=lam*s2,sigma2=s2,lam=lam)
def predict(fit,X): return np.c_[np.ones(len(X)),X]@fit['beta']
