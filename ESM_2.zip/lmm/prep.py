import pandas as pd, numpy as np
DB='/home/claude/data/db.xlsx'
def load(target):
    if target=='UCS':
        d=pd.read_excel(DB,'UCS_clean'); d['y']=np.log10(d.ucs_kpa)
    else:
        d=pd.read_excel(DB,'CBR_clean'); d=d[d.curing_days.notna()].copy(); d['y']=np.log10(d.cbr_value_pct)
        d['soaked']=(d.cbr_condition=='soaked').astype(float); d['cond_na']=d.cbr_condition.isna().astype(float)
    d['bio_dose']=d.additive1_dosage_pct; d['add_dose']=d.additive2_dosage_pct
    d['dose_na']=d.bio_dose.isna().astype(float)
    d['tot_dose']=d.bio_dose.fillna(0)+d.add_dose.fillna(0)
    d['lnt']=np.log1p(d.curing_days); d['dose_lnt']=d.tot_dose*d.lnt
    d['log_d50']=np.log10(d.d50_um); d['pi_ll']=d.pi_pct/d.ll_pct
    omc='omc_untreated_pct'
    d['mix']=d[['study_id','bio_dose','add_dose','additive1_name_raw','additive2_name_raw']].astype(object).fillna('na').astype(str).agg('|'.join,axis=1)
    return d.reset_index(drop=True)
SOIL=['soil_gs','log_d50','ll_pct','pl_pct','pi_pct','pi_ll','omc_untreated_pct','mdd_untreated_kgm3']
FAM_B=['bio_xg','bio_ch','bio_gg','bio_lg','bio_sls','bio_els']
FAM_A=['add_ppf','add_rha','add_li','add_swf','add_cw','add_hl','add_fa','add_nl_ns','add_cem','add_pf','add_ggbfs','add_gp']
TREAT=['bio_dose','dose_na','add_dose','tot_dose']
CUR=['curing_days','lnt','dose_lnt']
def famA(d): return [c for c in FAM_A+['add_rc','add_fa_rc'] if c in d.columns]
def feats(d,T,study_const=True):
    f=(SOIL if study_const else [])+FAM_B+famA(d)+TREAT+CUR
    if T=='CBR': f=f+['soaked','cond_na']
    return f
from sklearn.svm import SVR
def design(tr,te,cols,indicators=True):
    Xtr=tr[cols].astype(float).copy(); Xte=te[cols].astype(float).copy()
    med=Xtr.median()
    add=[]
    if indicators:
        for c in cols:
            if Xtr[c].isna().any() or Xte[c].isna().any():
                Xtr[c+'_na']=Xtr[c].isna().astype(float); Xte[c+'_na']=Xte[c].isna().astype(float)
    Xtr=Xtr.fillna(med).fillna(0); Xte=Xte.fillna(med).fillna(0)
    mu=Xtr.mean(); sd=Xtr.std().replace(0,1)
    Ztr=((Xtr-mu)/sd).clip(-4,4); Zte=((Xte-mu)/sd).clip(-4,4)
    return Ztr.values,Zte.values
def loso(d,fitpred):
    pred=np.full(len(d),np.nan)
    for s in sorted(d.study_id.unique()):
        te=(d.study_id==s).values; pred[te]=fitpred(d[~te],d[te])
    return pred
def metrics(d,pred):
    ps=[np.sqrt(((d.y[d.study_id==s]-pred[(d.study_id==s).values])**2).mean()) for s in sorted(d.study_id.unique())]
    R2=1-((d.y-pred)**2).sum()/((d.y-d.y.mean())**2).sum()
    return np.array(ps),R2
