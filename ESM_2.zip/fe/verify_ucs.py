import numpy as np, axicbr as A
def ucs(c_kPa, phi, E=200.0, nu=0.3, cone="outer", n=4):
    R, H = 50.0, 200.0
    xy, conn = A.mesh(R, H, R/2, n, n, 2*n, beta_r=0, beta_z=0, level=1)
    m = A.Model(xy, conn, E, nu, c_kPa*1e-3, phi, Hp_frac=0.0, cone=cone)
    nd = 2*len(xy); tol=1e-9
    fixed = {}
    for k in np.where(xy[:,1] < tol)[0]: fixed[2*k+1] = 0.0
    for k in np.where(xy[:,0] < tol)[0]: fixed[2*k] = 0.0
    top = np.where(np.abs(xy[:,1]-H) < tol)[0]; pz = [2*k+1 for k in top]
    presc = np.array(sorted(set(fixed)|set(pz))); free = np.setdiff1d(np.arange(nd), presc)
    u = np.zeros(nd); out=[]; Fext=np.zeros(nd)
    for strain in np.linspace(0.0005, 0.03, 60):
        up=np.zeros(nd); up[pz] = -0.0005*H
        u, F, ok, its = A.increment(m, u, up, presc, free, Fext, tol=1e-9, ref_dofs=pz)
        assert ok, (c_kPa, phi, strain)
        out.append(-F[pz].sum()/(np.pi*R*R)*1000)   # kPa
    return max(out)
for c, phi in [(100,10),(100,20),(100,30),(100,40),(150,25)]:
    q = ucs(c, phi); p=np.radians(phi); qmc = 2*c*np.cos(p)/(1-np.sin(p))
    print(f"c={c} kPa, phi={phi}: FE {q:.2f} kPa, closed form {qmc:.2f} kPa, error {100*(q/qmc-1):+.3f}%")
q = ucs(150, 25, cone="inner"); p=np.radians(25); qmc = 2*150*np.cos(p)/(1-np.sin(p))
print(f"inner cone, c=150, phi=25: FE/MC = {q/qmc:.3f} (3D model in the paper: 0.63)")
