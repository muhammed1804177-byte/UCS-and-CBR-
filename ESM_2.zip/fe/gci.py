import json, glob, numpy as np
D3 = {  # 3D quarter model (manuscript Table 6): L0..L3, extrapolated, GCI
 (30,35,150): dict(name="Stiff frictional", L=[258.6,250.9,242.1,238.2], ext=231.3, gci=3.6),
 (400,30,350): dict(name="Strong stiff", L=[563.6,540.9,514.2,500.2], ext=460.5, gci=9.9),
 (200,20,40): dict(name="Cohesive soft", L=[56.7,53.9,50.5,48.7], ext=43.2, gci=14.1),
 (60,25,60): dict(name="Representative", L=[76.6,69.5,61.0,56.5], ext=43.2, gci=29.5),
 (10,15,20): dict(name="Weak", L=[9.0,7.2,5.9,5.3], ext=3.8, gci=34.6)}
def rich(f):  # f = coarse..fine, ratio 2
    f1, f2, f3 = f[-3:]
    e32, e21 = f2 - f1, f3 - f2
    p = abs(np.log(abs(e32 / e21))) / np.log(2)
    ext = f3 + (f3 - f2) / (2 ** p - 1)
    gci = 1.25 * abs((f3 - f2) / f3) / (2 ** p - 1) * 100
    mono = np.sign(e32) == np.sign(e21)
    return p, ext, gci, mono
rows = []
for (c, ph, E), d in D3.items():
    fs = sorted(glob.glob(f"mesh_c{c:g}_p{ph:g}_E{E:g}*.json"))
    res = {}
    for f in fs:
        for r in json.load(open(f)): res[r["level"]] = r
    if len(res) < 3: print(d["name"], "incomplete", sorted(res)); continue
    lv = sorted(res); cb = [res[l]["CBR"] for l in lv]
    p, ext, gci, mono = rich(cb)
    rows.append(dict(name=d["name"], c=c, phi=ph, E=E, levels=lv, nel=[res[l]["nel"] for l in lv], CBR=cb, p=p, ext=ext, gci=gci, mono=bool(mono),
                     L1_3D=d["L"][1], L3_3D=d["L"][3], ext3D=d["ext"], gci3D=d["gci"], L1_over_conv=d["L"][1] / ext, ext3D_over_conv=d["ext"] / ext))
for r in rows:
    print(f"{r['name']:16s} CBR by level {['%.2f'%x for x in r['CBR']]}  p={r['p']:.2f}  extrap={r['ext']:.2f}%  GCI={r['gci']:.2f}%  monotone={r['mono']}"
          f" | 3D: L1 {r['L1_3D']} L3 {r['L3_3D']} ext {r['ext3D']} (GCI {r['gci3D']}%) | L1/conv {r['L1_over_conv']:.2f}  3Dext/conv {r['ext3D_over_conv']:.2f}")
json.dump(rows, open("gci_summary.json", "w"), indent=1)
