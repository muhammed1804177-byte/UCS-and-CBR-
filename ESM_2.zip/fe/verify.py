import numpy as np, time, axicbr as A
a=24.8; E=100.0; nu=0.3
print("V1 elastic rigid punch (smooth), domain 20a x 20a; Sneddon P = 2 a E d / (1-nu^2)")
for lev in (1,2,4,8):
    t=time.time()
    r=A.run_cbr(E,nu,1e7,30,level=lev,base=(4,6,8),rough=False,surcharge_kPa=0.0,R=20*a,Hs=20*a,a=a,beta=(2.2,2.4),steps=np.array([0.1]))
    P=r['hist'][-1,1]*1000; Ps=2*a*E*0.1/(1-nu**2)
    print(f"  level {lev}: elements {r['nel']}, P = {P:.2f} N, Sneddon {Ps:.2f} N, ratio {P/Ps:.4f}  ({time.time()-t:.1f}s)")
