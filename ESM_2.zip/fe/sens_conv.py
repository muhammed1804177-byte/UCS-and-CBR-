import json, sys, time, axicbr as A
CASES=[(30,35,150),(400,30,350),(200,20,40),(60,25,60),(10,15,20)]
LEVEL=4; out=[]
variants=[('base',dict()),('smooth',dict(rough=False)),('Hp0.001',dict(Hp_frac=0.001)),('Hp0.02',dict(Hp_frac=0.02)),('inner',dict(cone='inner'))]
for c,ph,E in CASES:
    for name,kw in variants:
        t=time.time(); r=A.run_cbr(E,0.3,c,ph,level=LEVEL,base=(6,8,10),**kw)
        rec=dict(c=c,phi=ph,E=E,variant=name,ok=r['ok'],CBR=r.get('CBR'),sec=time.time()-t)
        out.append(rec); print(json.dumps(rec),flush=True); json.dump(out,open('sens_conv.json','w'),indent=1)
