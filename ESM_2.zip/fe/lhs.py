import numpy as np, json, time, sys, axicbr as A
from scipy.stats import qmc
n = int(sys.argv[1]) if len(sys.argv) > 1 else 40
LEVEL = int(sys.argv[2]) if len(sys.argv) > 2 else 2
s = qmc.LatinHypercube(d=4, seed=2026, optimization="random-cd").random(n)
lo = np.array([np.log10(5), 10, np.log10(5), 0.25]); hi = np.array([np.log10(800), 40, np.log10(400), 0.40])
X = lo + s * (hi - lo)
out = []
for i, (lc, ph, lE, nu) in enumerate(X):
    c, E = 10 ** lc, 10 ** lE
    t = time.time(); r = A.run_cbr(E, nu, c, ph, level=LEVEL, base=(6, 8, 10), rough=True)
    rec = dict(i=i, c=c, phi=ph, E=E, nu=nu, ok=r["ok"], CBR=r.get("CBR"), sec=time.time() - t)
    out.append(rec); print(json.dumps(rec), flush=True)
    json.dump(out, open(f"lhs_level{LEVEL}.json", "w"), indent=1)
