import numpy as np, time, json, sys, axicbr as A
c, phi, E = [float(x) for x in sys.argv[1:4]]; levels=[int(x) for x in sys.argv[4].split(',')]
nu=0.3; out=[]
for lev in levels:
    t=time.time(); r=A.run_cbr(E,nu,c,phi,level=lev,base=(6,8,10),rough=True)
    if not r['ok']: print(f"level {lev}: FAILED at {r['failed_at']}"); continue
    out.append(dict(level=lev,nel=r['nel'],ndof=r['ndof'],P25=r['P25'],P50=r['P50'],CBR=r['CBR'],sec=time.time()-t))
    print(f"level {lev}: el {r['nel']:6d}  dof {r['ndof']:7d}  P2.5 {r['P25']:.3f} kN  P5.0 {r['P50']:.3f} kN  CBR {r['CBR']:.2f}%  ({time.time()-t:.0f}s)", flush=True)
json.dump(out, open(f"mesh_c{c:g}_p{phi:g}_E{E:g}.json","w"), indent=1)
