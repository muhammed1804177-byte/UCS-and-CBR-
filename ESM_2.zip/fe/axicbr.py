"""
Axisymmetric small-strain elasto-plastic FE model of the CBR test (and of the UCS test for verification).

Elements : 8-node serendipity quadrilaterals (Q8), 2x2 Gauss integration (reduced), axisymmetric
Material : Drucker-Prager, f = alpha*I1 + sqrt(J2) - k, associated flow, linear isotropic hardening
           of k; closed-form return mapping (cone and apex) with the consistent algorithmic tangent
Loading  : displacement-controlled rigid plunger (rough: u_r = 0 and u_z prescribed under the plunger;
           smooth: only u_z prescribed), smooth rigid mould wall (u_r = 0), fixed base, surcharge on annulus
Units    : mm, N, MPa
Mesh     : structured, self-similar family (refinement by subdivision in parametric space), clustered
           toward the plunger edge r = a and toward the surface, so Richardson extrapolation is valid.
"""
import numpy as np, scipy.sparse as sp, os, time
os.environ.setdefault("PYPARDISO_MKL_RT", "/usr/local/lib/libmkl_rt.so.3")
try:
    import pypardiso
    def solve(A, b): return pypardiso.spsolve(A, b)
except Exception:  # pragma: no cover
    from scipy.sparse.linalg import spsolve as _s
    def solve(A, b): return _s(A.tocsc(), b)

SQ2 = np.sqrt(2.0)
M = np.array([1.0, 1.0, 1.0, 0.0])                     # Mandel identity (rr, zz, tt, rz)
IDEV = np.eye(4) - np.outer(M, M) / 3.0
T = np.diag([1.0, 1.0, 1.0, 1.0 / SQ2])                # engineering <-> Mandel

# ---------------------------------------------------------------- Drucker-Prager parameters
def dp_outer(c, phi):      # matches Mohr-Coulomb in triaxial compression
    s = np.sin(phi); return 2 * s / (np.sqrt(3) * (3 - s)), 6 * c * np.cos(phi) / (np.sqrt(3) * (3 - s))
def dp_inner(c, phi):      # inscribed cone
    t = np.tan(phi); d = np.sqrt(9 + 12 * t * t); return t / d, 3 * c / d

# ---------------------------------------------------------------- Q8 element
GP = np.array([-1, 1]) / np.sqrt(3.0)
XI = np.array([[-1, -1], [1, -1], [1, 1], [-1, 1], [0, -1], [1, 0], [0, 1], [-1, 0]], float)
def q8_shape(x, e):
    N = np.zeros(8); dN = np.zeros((8, 2))
    for i in range(4):
        xi, ei = XI[i]
        N[i] = 0.25 * (1 + x * xi) * (1 + e * ei) * (x * xi + e * ei - 1)
        dN[i, 0] = 0.25 * xi * (1 + e * ei) * (2 * x * xi + e * ei)
        dN[i, 1] = 0.25 * ei * (1 + x * xi) * (x * xi + 2 * e * ei)
    for i in (4, 6):
        ei = XI[i, 1]; N[i] = 0.5 * (1 - x * x) * (1 + e * ei); dN[i] = [-x * (1 + e * ei), 0.5 * ei * (1 - x * x)]
    for i in (5, 7):
        xi = XI[i, 0]; N[i] = 0.5 * (1 + x * xi) * (1 - e * e); dN[i] = [0.5 * xi * (1 - e * e), -e * (1 + x * xi)]
    return N, dN
SHP = [q8_shape(x, e) for e in GP for x in GP]          # 4 Gauss points, weight 1 each

# ---------------------------------------------------------------- mesh
def cluster(n, x0, x1, toward, beta):
    """n intervals on [x0,x1] clustered toward 'toward' (x0 or x1) with strength beta (0 = uniform)."""
    s = np.linspace(0, 1, n + 1)
    if beta > 0:
        s = np.tanh(beta * s) / np.tanh(beta)            # dense near s = 0
    return (x0 + (x1 - x0) * s) if toward == x0 else (x1 - (x1 - x0) * s)[::-1]

def mesh(R, Hs, a, n_in, n_out, nz, beta_r=1.6, beta_z=1.8, level=1):
    """Self-similar mesh: base element counts (n_in, n_out, nz) multiplied by 'level'; node lines at r = a.
    The parametric clustering functions are fixed, so refinement subdivides the same mapping."""
    ni, no, nzz = n_in * level, n_out * level, nz * level
    # build on a 2x finer parametric grid so that mid-side nodes lie on the same mapping
    r_in = cluster(2 * ni, 0.0, a, a, beta_r)            # dense toward r = a
    r_out = cluster(2 * no, a, R, a, beta_r)
    r = np.concatenate([r_in, r_out[1:]])
    z = cluster(2 * nzz, 0.0, Hs, Hs, beta_z)            # dense toward the surface z = Hs
    NR, NZ = len(r), len(z)
    gid = -np.ones((NZ, NR), int)
    ner, nez = ni + no, nzz
    conn = np.zeros((ner * nez, 8), int)
    used = np.zeros((NZ, NR), bool)
    e = 0
    for j in range(nez):
        for i in range(ner):
            I, J = 2 * i, 2 * j
            loc = [(J, I), (J, I + 2), (J + 2, I + 2), (J + 2, I), (J, I + 1), (J + 1, I + 2), (J + 2, I + 1), (J + 1, I)]
            for jj, ii in loc: used[jj, ii] = True
            conn[e] = [jj * NR + ii for jj, ii in loc]; e += 1
    flat = used.ravel(); new = -np.ones(flat.size, int); new[flat] = np.arange(flat.sum())
    conn = new[conn]
    RR, ZZ = np.meshgrid(r, z)
    xy = np.stack([RR.ravel()[flat], ZZ.ravel()[flat]], 1)
    return xy, conn

# ---------------------------------------------------------------- model
class Model:
    def __init__(self, xy, conn, E, nu, c, phi_deg, Hp_frac=0.005, cone="outer"):
        self.xy, self.conn = xy, conn
        self.ne, self.nn = len(conn), len(xy)
        self.E, self.nu = E, nu
        self.K = E / (3 * (1 - 2 * nu)); self.G = E / (2 * (1 + nu))
        phi = np.radians(phi_deg)
        self.alpha, self.k0 = (dp_outer if cone == "outer" else dp_inner)(c, phi)
        # hardening of k chosen so that the uniaxial-compression hardening modulus equals Hp_frac*E
        self.Hk = Hp_frac * E * (self.alpha + 1 / np.sqrt(3)) ** 2
        self._geometry()
        ng = self.ne * 4
        self.sig = np.zeros((ng, 4)); self.eps_p = np.zeros(ng)
        De = self.K * np.outer(M, M) + 2 * self.G * IDEV      # Mandel elastic tensor
        self.De = De
        self.Dlast = np.broadcast_to(De, (ng, 4, 4)).copy()

    def _geometry(self):
        X = self.xy[self.conn]                                 # (ne, 8, 2)
        B = np.zeros((self.ne, 4, 4, 16)); dV = np.zeros((self.ne, 4)); rgp = np.zeros((self.ne, 4))
        for g, (N, dN) in enumerate(SHP):
            J = np.einsum("ia,eib->eab", dN, X)               # (ne,2,2): dX/dxi
            detJ = J[:, 0, 0] * J[:, 1, 1] - J[:, 0, 1] * J[:, 1, 0]
            assert (detJ > 0).all()
            Jinv = np.linalg.inv(J)
            dNx = np.einsum("ia,eab->eib", dN, Jinv)          # (ne,8,2) dN/dr, dN/dz
            r = X[:, :, 0] @ N
            rgp[:, g] = r
            for i in range(8):
                B[:, g, 0, 2 * i] = dNx[:, i, 0]              # e_rr
                B[:, g, 1, 2 * i + 1] = dNx[:, i, 1]          # e_zz
                B[:, g, 2, 2 * i] = N[i] / r                  # e_tt
                B[:, g, 3, 2 * i] = dNx[:, i, 1] / SQ2        # Mandel shear = gamma/sqrt2
                B[:, g, 3, 2 * i + 1] = dNx[:, i, 0] / SQ2
            dV[:, g] = 2 * np.pi * r * detJ
        self.B, self.dV, self.rgp = B, dV, rgp
        dofs = np.stack([2 * self.conn, 2 * self.conn + 1], -1).reshape(self.ne, 16)
        self.dofs = dofs
        self.I = np.repeat(dofs, 16, 1).ravel(); self.Jx = np.tile(dofs, (1, 16)).ravel()

    def strain(self, u):
        ue = u[self.dofs]                                     # (ne,16)
        return np.einsum("egij,ej->egi", self.B, ue).reshape(-1, 4)

    def constitutive(self, deps, commit=False):
        """Return mapping from the committed state with total strain increment deps (Mandel)."""
        K, G, a, Hk = self.K, self.G, self.alpha, self.Hk
        st = self.sig + deps @ self.De.T
        p = st[:, :3].sum(1) / 3; s = st - np.outer(p, M)
        q = np.sqrt(0.5 * np.einsum("gi,gi->g", s, s))         # sqrt(J2)  (Mandel: s:s = sum s_i^2)
        k = self.k0 + Hk * self.eps_p
        f = 3 * a * p + q - k
        Dt = np.broadcast_to(self.De, (len(st), 4, 4)).copy()
        sig = st.copy(); dg = np.zeros(len(st))
        pl = f > 1e-12 * max(1.0, abs(self.k0))
        if pl.any():
            A = G + 9 * K * a * a + Hk
            dgl = f[pl] / A
            cone = q[pl] - G * dgl > 0
            idx = np.where(pl)[0]
            ic = idx[cone]; dgc = dgl[cone]; qc = q[ic]
            n = s[ic] / qc[:, None]                            # s/q  (n:n = 2)
            sig[ic] = s[ic] * (1 - G * dgc / qc)[:, None] + np.outer(p[ic] - 3 * K * a * dgc, M)
            dg[ic] = dgc
            # consistent tangent (Mandel)
            c1 = 2 * G * (1 - G * dgc / qc)
            c2 = G * G * (dgc / qc - 1 / A)
            c3 = -3 * a * K * G / A
            c4 = K - 9 * a * a * K * K / A
            Dt[ic] = (c1[:, None, None] * IDEV + c2[:, None, None] * np.einsum("gi,gj->gij", n, n)
                      + c3 * (np.einsum("gi,j->gij", n, M) + np.einsum("i,gj->gij", M, n)) + c4 * np.outer(M, M))
            ia = idx[~cone]
            if len(ia):                                        # apex return
                # volumetric return to the apex with hardening: 3a(p_tr - K*3a*dg) = k0 + Hk(ep+dg)  (dev part vanishes)
                dga = (3 * a * p[ia] - (self.k0 + Hk * self.eps_p[ia])) / (9 * a * a * K + Hk)
                pa = p[ia] - 3 * a * K * dga
                sig[ia] = np.outer(pa, M); dg[ia] = dga
                Dt[ia] = (K * Hk / (9 * a * a * K + Hk)) * np.outer(M, M) + 1e-3 * self.De
        if commit:
            self.sig = sig; self.eps_p = self.eps_p + dg; self.Dlast = Dt
        return sig, Dt

    def assemble(self, sig, Dt, need_K=True):
        S = sig.reshape(self.ne, 4, 4)
        fe = np.einsum("egij,egi,eg->ej", self.B, S, self.dV)
        F = np.zeros(2 * self.nn); np.add.at(F, self.dofs.ravel(), fe.ravel())
        if not need_K: return F, None
        D = Dt.reshape(self.ne, 4, 4, 4)
        Ke = np.einsum("egia,egij,egjb,eg->eab", self.B, D, self.B, self.dV, optimize=True)
        Kg = sp.csr_matrix((Ke.ravel(), (self.I, self.Jx)), shape=(2 * self.nn, 2 * self.nn))
        return F, Kg

# ---------------------------------------------------------------- incremental solver
def increment(m, u, du_presc, presc, free, Fext, tol=1e-7, maxit=40, ref_dofs=None, verbose=False):
    """One displacement-controlled increment: tangent predictor (committed tangent) + full Newton."""
    du = np.zeros_like(u); du[presc] = du_presc[presc]
    # predictor with the committed tangent and committed stresses
    F0, K0 = m.assemble(m.sig, m.Dlast)
    rhs = (F0 - Fext)[free] + K0[free][:, presc] @ du[presc]
    du[free] = -solve(K0[free][:, free], rhs)
    for it in range(maxit):
        sig, Dt = m.constitutive(m.strain(u + du) - m.strain(u))
        F, Kg = m.assemble(sig, Dt)
        r = (F - Fext)[free]
        ref = max(1.0, np.linalg.norm(F[ref_dofs]) if ref_dofs is not None else 1.0, np.linalg.norm(Fext))
        rn = np.linalg.norm(r) / ref
        if verbose: print(f"     it {it}: {rn:.2e}")
        if rn < tol:
            m.constitutive(m.strain(u + du) - m.strain(u), commit=True)
            return u + du, F, True, it
        d = -solve(Kg[free][:, free], r)
        # simple backtracking line search on the residual norm
        step = 1.0
        for _ in range(6):
            trial = du.copy(); trial[free] += step * d
            s2, _D = m.constitutive(m.strain(u + trial) - m.strain(u))
            F2, _ = m.assemble(s2, _D, need_K=False)
            if np.linalg.norm((F2 - Fext)[free]) / ref < rn or step < 0.1: break
            step *= 0.5
        du[free] += step * d
    return u, None, False, maxit

# ---------------------------------------------------------------- boundary conditions & drivers
def edge_load(xy, nodes_sorted, pressure):
    """Consistent nodal z-loads (downward) for a uniform pressure on a top edge made of quadratic segments."""
    F = np.zeros(len(xy))
    g3 = np.array([-np.sqrt(0.6), 0, np.sqrt(0.6)]); w3 = np.array([5, 8, 5]) / 9
    for k in range(0, len(nodes_sorted) - 2, 2):
        n0, n1, n2 = nodes_sorted[k:k + 3]
        r = xy[[n0, n1, n2], 0]
        for x, w in zip(g3, w3):
            N = np.array([0.5 * x * (x - 1), 1 - x * x, 0.5 * x * (x + 1)]); dN = np.array([x - 0.5, -2 * x, x + 0.5])
            rr = N @ r; L = dN @ r
            F[[n0, n1, n2]] += -pressure * N * 2 * np.pi * rr * L * w
    return F

def run_cbr(E, nu, c_kPa, phi, level=1, base=(6, 8, 10), rough=True, Hp_frac=0.005, cone="outer",
            surcharge_kPa=2.5, R=76.0, Hs=116.4, a=24.8, beta=(1.6, 1.8), steps=None, verbose=False):
    xy, conn = mesh(R, Hs, a, *base, beta_r=beta[0], beta_z=beta[1], level=level)
    m = Model(xy, conn, E, nu, c_kPa * 1e-3, phi, Hp_frac, cone)
    nd = 2 * len(xy); tol = 1e-9 * R
    top = np.where(np.abs(xy[:, 1] - Hs) < tol)[0]
    plunger = top[xy[top, 0] <= a + tol]; ann = top[xy[top, 0] >= a - tol]
    ann = ann[np.argsort(xy[ann, 0])]
    fixed = {}
    for n in np.where(np.abs(xy[:, 1]) < tol)[0]: fixed[2 * n] = 0.0; fixed[2 * n + 1] = 0.0
    for n in np.where(xy[:, 0] < tol)[0]: fixed[2 * n] = 0.0
    for n in np.where(np.abs(xy[:, 0] - R) < tol)[0]: fixed[2 * n] = 0.0
    pz = [2 * n + 1 for n in plunger]
    if rough:
        for n in plunger: fixed[2 * n] = 0.0
    Fext = np.zeros(nd); Fext[1::2] = edge_load(xy, ann, surcharge_kPa * 1e-3)
    if steps is None:
        steps = np.concatenate([np.arange(0.02, 0.2001, 0.02), np.arange(0.25, 2.5001, 0.05)[1:] if False else np.arange(0.25, 2.5001, 0.05),
                                np.arange(2.6, 5.0001, 0.1), [5.1]])
    steps = np.round(np.unique(steps), 6)
    u = np.zeros(nd); hist = []
    presc = np.array(sorted(set(fixed) | set(pz)))
    free = np.setdiff1d(np.arange(nd), presc)
    targets = list(np.concatenate([[0.0], steps])); prev = 0.0; k = 0
    while k < len(targets):
        target = targets[k]
        up = np.zeros(nd); up[pz] = -(target - prev)
        un, F, ok, its = increment(m, u, up, presc, free, Fext, ref_dofs=pz, verbose=verbose)
        if not ok:
            mid = 0.5 * (prev + target)
            if target - prev < 1e-3:
                return dict(ok=False, failed_at=target, hist=np.array(hist), nel=len(conn), ndof=len(free))
            targets.insert(k, mid); continue
        u = un; prev = target; k += 1
        hist.append((target, -F[pz].sum() / 1000.0))
    h = np.array(hist)
    P25 = np.interp(2.5, h[:, 0], h[:, 1]); P50 = np.interp(5.0, h[:, 0], h[:, 1])
    cbr = 100 * max(P25 / 13.24, P50 / 19.96)
    return dict(ok=True, P25=P25, P50=P50, CBR=cbr, hist=h, nel=len(conn), ndof=len(free))
