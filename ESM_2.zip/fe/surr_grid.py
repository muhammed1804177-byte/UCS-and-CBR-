import numpy as np, json, time, axicbr as A
Q=np.logspace(np.log10(60),np.log10(3000),6); PHI=np.arange(10,41,5.0); K=np.logspace(np.log10(3),np.log10(150),6)
out=[]
for q in Q:
  for ph in PHI:
    s=np.sin(np.radians(ph)); c=q*(1-s)/(2*np.cos(np.radians(ph)))
    for k in K:
        E=k*q/1000.0  # MPa
        t=time.time(); r=A.run_cbr(E,0.3,c,ph,level=2,base=(6,8,10),rough=True)
        rec=dict(q=q,phi=ph,kappa=k,c=c,E=E,ok=r['ok'],CBR=r.get('CBR'),sec=time.time()-t); out.append(rec)
        print(json.dumps(rec),flush=True); json.dump(out,open('surr_grid.json','w'))
