import numpy as np, json, pandas as pd, sys
from scipy.interpolate import RegularGridInterpolator as RGI
sys.path.insert(0,'/home/claude/fe')
BIAS=np.mean([241.05/230.38,497.17/475.04,47.156/45.13,53.6/50.92,4.67/4.39])
g=json.load(open('/home/claude/fe/surr_grid.json'))
Q=sorted({r['q'] for r in g}); PH=sorted({r['phi'] for r in g}); K=sorted({r['kappa'] for r in g})
A=np.full((len(Q),len(PH),len(K)),np.nan)
for r in g:
    if r['ok']: A[Q.index(r['q']),PH.index(r['phi']),K.index(r['kappa'])]=np.log10(r['CBR']/BIAS)
assert not np.isnan(A).any(), np.isnan(A).sum()
f=RGI((np.log10(Q),PH,np.log10(K)),A,method='cubic' if all(len(x)>=4 for x in (Q,PH,K)) else 'linear')
def surr(q,phi,kap): 
    q=np.clip(q,Q[0],Q[-1]); return f(np.c_[np.log10(q),np.broadcast_to(phi,q.shape),np.broadcast_to(np.log10(kap),q.shape)])
pairs=pd.read_csv('/home/claude/lmm/pairs.csv'); pairs['lu']=np.log10(pairs.ucs); pairs['lc']=np.log10(pairs.cbr)
PHg=np.arange(10,40.01,1.0); Kg=np.logspace(np.log10(3),np.log10(150),60)
def surface(df):
    S=np.zeros((len(PHg),len(Kg)))
    for i,ph in enumerate(PHg):
        for j,k in enumerate(Kg): S[i,j]=np.sqrt(((surr(df.ucs.values,ph,k)-df.lc.values)**2).mean())
    return S
S=surface(pairs); i,j=np.unravel_index(S.argmin(),S.shape)
near=S<=1.05*S.min()
kap_band=[Kg[near[r]].min() if near[r].any() else np.nan for r in range(len(PHg))]
kap_band_hi=[Kg[near[r]].max() if near[r].any() else np.nan for r in range(len(PHg))]
print('pairs',len(pairs),pairs.study.nunique(),'min RMSE %.3f at phi %g kappa %.1f'%(S.min(),PHg[i],Kg[j]))
print('phi with a kappa within 5%:',PHg[near.any(1)].min(),PHg[near.any(1)].max(),'kappa range',np.nanmin(kap_band),np.nanmax(kap_band_hi))
kopt={ph:Kg[S[r].argmin()] for r,ph in enumerate(PHg)}
# LOSO
studies=sorted(pairs.study.unique()); P={m:np.zeros(len(pairs)) for m in ['FE chain (converged)','Power law','Constant ratio','Training mean']}
for s in studies:
    te=(pairs.study==s).values; tr=pairs[~te]
    St=surface(tr); a,b=np.unravel_index(St.argmin(),St.shape)
    P['FE chain (converged)'][te]=surr(pairs.ucs.values[te],PHg[a],Kg[b])
    B=np.polyfit(tr.lu,tr.lc,1); P['Power law'][te]=np.polyval(B,pairs.lu[te])
    P['Constant ratio'][te]=pairs.lu[te]+(tr.lc-tr.lu).mean()
    P['Training mean'][te]=tr.lc.mean()
res={}
y=pairs.lc.values
for m,p in P.items():
    R2=1-((y-p)**2).sum()/((y-y.mean())**2).sum(); rm=np.sqrt(((y-p)**2).mean())
    ps=np.mean([np.sqrt(((y[pairs.study==s]-p[(pairs.study==s).values])**2).mean()) for s in studies])
    res[m]=dict(R2=R2,RMSE=rm,perstudy=ps); print(f'{m:22s} R2 {R2:6.2f} RMSE {rm:.3f} per-study {ps:.3f}')
json.dump(dict(S=S.tolist(),PHg=PHg.tolist(),Kg=Kg.tolist(),min=float(S.min()),phi_opt=float(PHg[i]),k_opt=float(Kg[j]),band_lo=kap_band,band_hi=kap_band_hi,kopt={str(k):float(v) for k,v in kopt.items()},loso=res,bias=BIAS,npairs=len(pairs),nstudies=int(pairs.study.nunique())),open('link_results.json','w'),indent=1,default=float)
