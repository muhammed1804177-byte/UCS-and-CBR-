import numpy as np, json, sys, pandas as pd
sys.path.insert(0,'/home/claude/fe'); import axicbr as A
L=json.load(open('link_results.json')); kopt={float(k):v for k,v in L['kopt'].items()}; BIAS=L['bias']
dig=json.load(open('/home/claude/val/banne_cbr_digitized.json'))
C={'A':[0.15,0.24,0.29,0.27],'B':[0.15,0.27,0.31,0.25],'C':[0.15,0.33,0.35,0.33],'D':[0.15,0.31,0.33,0.32]}
P={'A':[22.81,26.35,25.71,25.96],'B':[22.81,28.23,29.29,31.92],'C':[22.81,29.46,31.04,34.87],'D':[22.81,29.24,30.41,31.29]}
pairs=pd.read_csv('/home/claude/lmm/pairs.csv'); B=np.polyfit(np.log10(pairs.ucs),np.log10(pairs.cbr),1); tm=np.log10(pairs.cbr).mean()
rows=[]
for t in 'ABCD':
    for i,gg in enumerate([0,1,2,3]):
        c=C[t][i]*98.0665; ph=P[t][i]; s=np.sin(np.radians(ph)); q=2*c*np.cos(np.radians(ph))/(1-s)
        k=kopt[round(ph)] if round(ph) in kopt else kopt[min(kopt,key=lambda x:abs(x-ph))]
        r=A.run_cbr(k*q/1000,0.3,c,ph,level=2,base=(6,8,10)); fe=r['CBR']/BIAS
        meas=dig[t][2*i+1]
        rows.append(dict(type=t,gg=gg,c=c,phi=ph,q=q,kappa=k,meas=meas,fe=fe,pl=10**np.polyval(B,np.log10(q)),tm=10**tm))
        print(rows[-1],flush=True)
df=pd.DataFrame(rows); df.to_csv('banne_check.csv',index=False)
for m in ['fe','pl','tm']:
    e=np.log10(df[m])-np.log10(df.meas); print(m,'RMSE log %.3f bias %.3f'%(np.sqrt((e**2).mean()),e.mean()))
from scipy.stats import spearmanr
print('spearman fe',spearmanr(df.fe,df.meas)[0],'pl',spearmanr(df.pl,df.meas)[0])
