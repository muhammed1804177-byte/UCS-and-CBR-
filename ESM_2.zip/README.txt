Online Resource 2 - reproducibility package

Database: Baghbani et al. (2026a), Zenodo doi 10.5281/zenodo.19242690, file "Organized data (journal ready).xlsx"
(MD5 9eb439cddea98533e553f3e81f0d4cfa). Edit the DB path at the top of lmm/prep.py.

fe/    Axisymmetric reference model of the CBR test (Online Resource 1, Text S4)
       axicbr.py solver; verify_ucs.py, verify.py (Sneddon 1965); cbr_mesh.py c phi E levels; gci.py;
       lhs.py (sensitivity); sens_conv.py (friction, hardening, cone on level 4); surr_grid.py (252-run surrogate)
lmm/   prep.py (features, folds), lmm.py (random-intercept REML), run_lmm.py (Table S21 upper part),
       calib.py (Table S21 lower part); pairs.csv = reconstructed UCS-CBR pairs (86)
link/  link.py (converged UCS-CBR link, Table 7 lower block); banne.py (external test, Table S22)
external_test/ banne_cbr_digitized.json: CBR digitized from Banne et al. (2024) Fig. 10
       (per soil type: soaked/unsoaked for 0, 1, 2 and 3% guar gum)
figure_scripts/, figure_data/  all figures; *_digitized*.csv were digitized from the original figures and validated
       against the reported tables. Some scripts redraw panels from the original raster figures (place them in figs/in).
Paths in the scripts point to /home/claude/...; adjust them to your folder.
Requirements: Python 3.10+, numpy, scipy, pandas, scikit-learn, openpyxl, matplotlib; optional pypardiso.
